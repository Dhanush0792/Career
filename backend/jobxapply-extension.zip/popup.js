import { buildAutofillPayload, getPortalRule, PORTAL_MAPS } from "./shared.js";
import JDMatcher from "./jd-matcher.js";
import CoverLetterEngine from "./cover-letter-engine.js";
import { buildResumePdf, createResumeFile, downloadResumePdf, injectPdfToFileInput } from "./resume-pdf-builder.js";

let popupActiveJob = { title: "", company: "", description: "", location: "", url: "" };
let popupActiveProfile = {};

// ── Status Helpers ──────────────────────────────────────────────────────────
function setStatus(msg, cls = "") {
  const el = document.getElementById("status");
  if (!el) return;
  el.textContent = msg;
  el.className = "status " + cls;
}

function setLoginStatus(msg, cls = "") {
  const el = document.getElementById("loginStatus");
  if (!el) return;
  el.textContent = msg;
  el.className = "status " + cls;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// ── Tab Management ──────────────────────────────────────────────────────────
function setupTabs() {
  const tabBtns = document.querySelectorAll(".nav-tab");
  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-tab");
      tabBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      document.querySelectorAll(".tab-pane").forEach((pane) => {
        pane.style.display = pane.id === targetId ? "flex" : "none";
      });

      if (targetId === "trackerTab") {
        loadTrackerMetadata();
      }
      if (targetId === "aiResumeTab") {
        loadPopupActiveJobAi();
      }
    });
  });
}

// ── Portal Detection ────────────────────────────────────────────────────────
async function loadPortalInfo() {
  const tab = await getActiveTab();
  const rule = getPortalRule(tab?.url || "");
  const nameEl = document.getElementById("portalName");
  const tierEl = document.getElementById("portalTier");
  const dotEl  = document.getElementById("portalDot");
  if (nameEl) nameEl.textContent = rule.portal || "Unknown Site";
  if (tierEl) tierEl.textContent = rule.notes ? `${rule.tier} · ${rule.notes}` : rule.tier || "";
  if (dotEl) {
    if (!rule.portal || rule.portal === "unknown") dotEl.classList.add("unknown");
    else dotEl.classList.remove("unknown");
  }
  return { tab, rule };
}

// ── Multi-Persona & Profile State ───────────────────────────────────────────
async function checkAuthState() {
  const local = await new Promise((r) =>
    chrome.storage.local.get(
      ["jobxapplyProfile", "jobxapplyProfiles", "jobxapplyActiveProfileId", "jobxapplyPasscode", "jobxapplyToken", "jobxapplyEmail"],
      r
    )
  );

  let profiles = local.jobxapplyProfiles || {};
  let activeId = local.jobxapplyActiveProfileId || Object.keys(profiles)[0] || "default";
  let profile = profiles[activeId] || local.jobxapplyProfile || {};

  const hasCredentials = !!(local.jobxapplyPasscode || local.jobxapplyToken);
  const hasData = profile && !!(profile.fullName || profile.email || profile.phone);

  const loginView = document.getElementById("loginView");
  const autofillView = document.getElementById("autofillView");
  const navTabs = document.getElementById("navTabs");

  if (hasCredentials || hasData) {
    if (loginView) loginView.style.display = "none";
    if (autofillView) autofillView.style.display = "flex";
    if (navTabs) navTabs.style.display = "flex";
    
    renderPersonaSelector(profiles, activeId);
    await loadAndDisplayProfile(profile, local.jobxapplyEmail);
    renderSnippets(profile);
  } else {
    if (autofillView) autofillView.style.display = "none";
    if (navTabs) navTabs.style.display = "none";
    if (loginView) loginView.style.display = "flex";
  }
}

function renderPersonaSelector(profiles, activeId) {
  const group = document.getElementById("personaGroup");
  const select = document.getElementById("personaSelect");
  if (!group || !select) return;

  const profileKeys = Object.keys(profiles);
  if (profileKeys.length <= 1) {
    group.style.display = "none";
    return;
  }

  group.style.display = "flex";
  select.innerHTML = "";

  profileKeys.forEach((key) => {
    const p = profiles[key] || {};
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = p.profileName || p.targetRole || p.fullName || key;
    if (key === activeId) opt.selected = true;
    select.appendChild(opt);
  });

  select.onchange = async (e) => {
    const selectedKey = e.target.value;
    await new Promise((r) => chrome.storage.local.set({ jobxapplyActiveProfileId: selectedKey }, r));
    await checkAuthState();
    setStatus("Switched active persona", "success");
  };
}

async function loadAndDisplayProfile(cachedProfile = null, cachedEmail = "") {
  popupActiveProfile = cachedProfile || {};
  let profile = cachedProfile;
  if (!profile) {
    const local = await new Promise((r) =>
      chrome.storage.local.get(["jobxapplyProfile", "jobxapplyProfiles", "jobxapplyActiveProfileId", "jobxapplyEmail"], r)
    );
    let profiles = local.jobxapplyProfiles || {};
    let activeId = local.jobxapplyActiveProfileId || Object.keys(profiles)[0] || "default";
    profile = profiles[activeId] || local.jobxapplyProfile || {};
    cachedEmail = local.jobxapplyEmail || "";
  }

  const nameEl   = document.getElementById("profileName");
  const emailEl  = document.getElementById("profileEmail");
  const avatarEl = document.getElementById("profileAvatar");
  const applyBtn = document.getElementById("apply");

  const displayName = profile.fullName || (profile.firstName ? `${profile.firstName} ${profile.lastName || ""}`.trim() : "") || "Connected User";
  const displayEmail = profile.email || cachedEmail || "Profile ready";

  if (nameEl) nameEl.textContent = displayName;
  if (emailEl) emailEl.textContent = displayEmail;
  if (avatarEl) avatarEl.textContent = (displayName[0] || "U").toUpperCase();
  if (applyBtn) applyBtn.disabled = false;
  setStatus("Profile connected — ready to autofill", "success");

  return profile;
}

// ── Snippets Library ────────────────────────────────────────────────────────
function renderSnippets(profile = {}) {
  const listEl = document.getElementById("snippetList");
  if (!listEl) return;

  listEl.innerHTML = "";

  const items = [
    { title: "LinkedIn Profile", val: profile.linkedin },
    { title: "GitHub Portfolio", val: profile.github },
    { title: "Portfolio Website", val: profile.portfolio || profile.website },
    { title: "Email Address", val: profile.email },
    { title: "Phone Number", val: profile.phone },
    { title: "Target Role", val: profile.targetRole || profile.role },
    { title: "Work Authorization", val: profile.workAuthorization || "Authorized to work in country without visa sponsorship" },
    { title: "Notice Period", val: profile.noticePeriod || "Available immediately / 2 weeks" },
    { title: "Expected Salary", val: profile.expectedSalary },
    { title: "Professional Bio", val: profile.summary || profile.bio || profile.coverLetterDraft }
  ].filter((item) => item.val && String(item.val).trim().length > 0);

  if (!items.length) {
    listEl.innerHTML = `<div style="font-size:11px; color:rgba(244,247,255,0.4); text-align:center; padding:16px 0;">No snippets found. Fill in your profile details to populate.</div>`;
    return;
  }

  items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "snippet-item";
    row.innerHTML = `
      <div class="snippet-header">
        <span class="snippet-title">${item.title}</span>
        <span class="snippet-action">Copy & Paste</span>
      </div>
      <div class="snippet-val">${item.val}</div>
    `;

    row.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(item.val);
        const tab = await getActiveTab();
        if (tab?.id) {
          chrome.tabs.sendMessage(tab.id, { type: "jobxapply:insertText", text: item.val });
        }
        setStatus(`Copied & inserted ${item.title}`, "success");
      } catch (err) {
        setStatus("Copied to clipboard", "success");
      }
    });

    listEl.appendChild(row);
  });
}

// ── Application Tracker Logger ──────────────────────────────────────────────
async function loadTrackerMetadata() {
  const tab = await getActiveTab();
  if (!tab?.id) return;

  const companyInput = document.getElementById("trackerCompanyInput");
  const roleInput = document.getElementById("trackerRoleInput");

  chrome.tabs.sendMessage(tab.id, { type: "jobxapply:getJobMetadata" }, (res) => {
    if (res?.ok && res.metadata) {
      if (companyInput && !companyInput.value) companyInput.value = res.metadata.company || "";
      if (roleInput && !roleInput.value) roleInput.value = res.metadata.title || "";
    }
  });
}

async function logApplication(companyName = "", jobTitle = "", appStatus = "Applied") {
  const tab = await getActiveTab();
  const rule = getPortalRule(tab?.url || "");

  let company = companyName;
  let title = jobTitle;

  if (!company || !title) {
    // Attempt auto-extraction
    const meta = await new Promise((r) => {
      if (!tab?.id) return r(null);
      chrome.tabs.sendMessage(tab.id, { type: "jobxapply:getJobMetadata" }, (res) => r(res?.metadata || null));
    });
    if (meta) {
      if (!company) company = meta.company || rule.portal || "Unknown Company";
      if (!title) title = meta.title || "Job Application";
    }
  }

  company = company || rule.portal || "Application";
  title = title || "Position";

  const newApp = {
    id: "app_" + Date.now(),
    company: company,
    role: title,
    portal: rule.portal || "Web Portal",
    url: tab?.url || "",
    status: appStatus,
    appliedDate: new Date().toISOString().split("T")[0],
    notes: "Logged via JobXApply extension"
  };

  const stored = await new Promise((r) => chrome.storage.local.get(["jobxapplyApplications"], r));
  const apps = stored.jobxapplyApplications || [];
  apps.unshift(newApp);
  await new Promise((r) => chrome.storage.local.set({ jobxapplyApplications: apps }, r));

  // Sync to server if token available
  const auth = await new Promise((r) => chrome.storage.local.get(["jobxapplyToken"], r));
  if (auth.jobxapplyToken) {
    fetch("https://jobxapply-backend.onrender.com/api/applications", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${auth.jobxapplyToken}`
      },
      body: JSON.stringify(newApp)
    }).catch(() => {});
  }

  setStatus(`Logged application for ${company}`, "success");
}

// ── Direct Login with Sync Key ───────────────────────────────────────────────
async function handleDirectLogin() {
  const input = document.getElementById("loginPasscodeInput");
  const passcode = input?.value?.trim() || "";
  if (!passcode) {
    setLoginStatus("Please enter your Sync Key (Passcode)", "warn");
    return;
  }

  setLoginStatus("Connecting and decrypting profile...", "warn");
  // Clear any stale tokens or cached empty profiles
  await new Promise((r) =>
    chrome.storage.local.remove(["jobxapplyToken", "jobxapplyProfile", "jobxapplyProfiles", "jobxapplyState"], r)
  );
  await new Promise((r) => chrome.storage.local.set({ jobxapplyPasscode: passcode }, r));

  chrome.runtime.sendMessage({ type: "jobxapply:getProfile", force: true }, async (res) => {
    if (chrome.runtime.lastError) {
      setLoginStatus("Sync error: " + chrome.runtime.lastError.message, "error");
      return;
    }

    if (res?.profile && (res.profile.fullName || res.profile.email)) {
      setLoginStatus("Authenticated & synced!", "success");
      await checkAuthState();
    } else if (res?.ok) {
      setLoginStatus("Authenticated! Loading profile...", "success");
      await checkAuthState();
    } else {
      setLoginStatus(res?.error || "Could not decrypt profile with that key.", "error");
    }
  });
}

// ── Active Web Session Detection & Google Login ─────────────────────────────
async function detectActiveWebSession() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.url) continue;
      const url = tab.url.toLowerCase();
      if (url.includes("jobxapply.netlify.app") || url.includes("localhost:") || url.includes("127.0.0.1:")) {
        const syncBtn = document.getElementById("syncActiveWebBtn");
        if (syncBtn) {
          syncBtn.style.display = "block";
          syncBtn.onclick = () => pairWithTabSession(tab.id);
        }
        return tab;
      }
    }
  } catch (e) {
    console.warn("Could not query tabs for active session:", e);
  }
  return null;
}

async function pairWithTabSession(tabId) {
  setLoginStatus("Reading session from JobXApply tab...", "warn");
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({
        token: localStorage.getItem("jxa_token") || "",
        email: localStorage.getItem("jxa_user_email") || "",
        passcode: localStorage.getItem("jxa_passcode") || ""
      })
    });

    const session = results?.[0]?.result;
    if (session?.token) {
      chrome.storage.local.set({
        jobxapplyToken: session.token,
        jobxapplyEmail: session.email,
        jobxapplyPasscode: session.passcode
      }, () => {
        setLoginStatus("Authenticated & Synced!", "success");
        chrome.runtime.sendMessage({ type: "jobxapply:getProfile" }, () => {
          checkAuthState();
        });
      });
    } else {
      setLoginStatus("No active session in that tab. Sign in first.", "warn");
    }
  } catch (err) {
    setLoginStatus("Tab connection notice: Sign in on the opened page.", "warn");
  }
}

async function handleGoogleWebLogin() {
  const activeTab = await getActiveTab();
  let baseFrontend = "https://jobxapply.netlify.app";
  if (activeTab?.url && (activeTab.url.includes("localhost:") || activeTab.url.includes("127.0.0.1:"))) {
    try {
      const u = new URL(activeTab.url);
      baseFrontend = `${u.protocol}//${u.host}`;
    } catch (e) {}
  }
  const webAuthUrl = `${baseFrontend}/auth.html?source=extension`;
  chrome.tabs.create({ url: webAuthUrl });
  setLoginStatus("Select your Google account on the opened page to sync.", "warn");
}

// ── Logout / Disconnect ─────────────────────────────────────────────────────
async function handleDisconnect() {
  if (!confirm("Log out from the extension and remove cached profile data?")) return;

  await new Promise((r) =>
    chrome.storage.local.remove(
      ["jobxapplyProfile", "jobxapplyProfiles", "jobxapplyActiveProfileId", "jobxapplyPasscode", "jobxapplyToken", "jobxapplyEmail"],
      r
    )
  );

  setLoginStatus("Disconnected from JobXApply.", "warn");
  const input = document.getElementById("loginPasscodeInput");
  if (input) input.value = "";

  await checkAuthState();
}

function getBaseDomain(hostname) {
  const parts = hostname.replace("www.", "").split(".");
  if (parts.length > 2) {
    const pen = parts[parts.length - 2];
    if (["co", "com", "net", "org", "gov", "edu"].includes(pen) && parts.length > 2) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  return parts.join(".");
}

// ── Autofill ────────────────────────────────────────────────────────────────
async function doAutofill() {
  const { tab, rule } = await loadPortalInfo();
  if (!tab?.id) { setStatus("No active tab found", "error"); return; }

  const local = await new Promise((r) =>
    chrome.storage.local.get(["jobxapplyProfile", "jobxapplyProfiles", "jobxapplyActiveProfileId"], r)
  );
  let profiles = local.jobxapplyProfiles || {};
  let activeId = local.jobxapplyActiveProfileId || Object.keys(profiles)[0] || "default";
  let profile = profiles[activeId] || local.jobxapplyProfile || {};

  const hasData = profile && (profile.fullName || profile.email || profile.phone);
  if (!hasData) {
    setStatus("Profile is empty — sync your profile first!", "error");
    return;
  }

  setStatus("Running autofill…");
  const payload = buildAutofillPayload(profile, Object.keys(profile).filter(k => profile[k]));

  const mapData = await new Promise((r) => chrome.storage.local.get(["jobxapplyMaps", "jobxapplyCustomMaps"], r));
  const cached = mapData.jobxapplyMaps || null;
  let map = {};
  if (cached && cached.maps && cached.maps[rule.portal]) {
    map = { ...cached.maps[rule.portal] };
  } else if (cached && cached[rule.portal]) {
    map = { ...cached[rule.portal] };
  } else {
    map = { ...(PORTAL_MAPS[rule.portal] || {}) };
  }
  
  const customMaps = mapData.jobxapplyCustomMaps || {};
  try {
    const hostname = new URL(tab.url).hostname;
    const domain = getBaseDomain(hostname);
    if (customMaps[domain]) {
      map = { ...map, ...customMaps[domain] };
    }
  } catch (e) {}

  chrome.tabs.sendMessage(tab.id, { type: "jobxapply:applyAutofill", profile: payload, portalMap: map }, (res) => {
    if (chrome.runtime.lastError) {
      setStatus("Error: " + chrome.runtime.lastError.message, "error");
      return;
    }
    if (res?.filled > 0) {
      setStatus(`Filled ${res.filled} field(s)`, "success");
    } else {
      setStatus("No matching fields found on this page", "warn");
    }
  });
}

// ── Sync from Cloud ──────────────────────────────────────────────────────────
async function syncFromCloud() {
  setStatus("Syncing from cloud…");
  chrome.runtime.sendMessage({ type: "jobxapply:getProfile" }, async (res) => {
    if (chrome.runtime.lastError) {
      setStatus("Sync error: " + chrome.runtime.lastError.message, "error");
      return;
    }
    if (res?.profile && (res.profile.fullName || res.profile.email)) {
      setStatus("Profile synced from cloud", "success");
      await checkAuthState();
    } else {
      setStatus("No profile found on server.", "warn");
    }
  });
}

// ── Sync to Web Tab / Test Profile Helpers ─────────────────────────────────
async function syncToWebTab() {
  setStatus("Syncing active profile to website tab...");
  chrome.runtime.sendMessage({ type: "jobxapply:syncToWebTab" }, (res) => {
    if (chrome.runtime.lastError) {
      setStatus("Sync failed: " + chrome.runtime.lastError.message, "error");
      return;
    }
    if (res?.ok) {
      setStatus("Profile synced to website profile section!", "success");
    } else {
      setStatus(res?.error || "Could not sync to website tab.", "warn");
    }
  });
}

async function loadTestProfile() {
  setLoginStatus("Loading full mock test dataset...", "warn");
  chrome.runtime.sendMessage({ type: "jobxapply:loadMockProfile" }, async (res) => {
    if (chrome.runtime.lastError) {
      setLoginStatus("Error loading mock profile: " + chrome.runtime.lastError.message, "error");
      return;
    }
    if (res?.ok) {
      setLoginStatus("Mock profile loaded into extension!", "success");
      await checkAuthState();
      // Auto-trigger sync to open web tab if present
      syncToWebTab();
    }
  });
}


// ── AI Resume & Cover Letter Popup Helpers ─────────────────────────────────
async function loadPopupActiveJobAi() {
  const titleEl = document.getElementById("popupAiJobTitle");
  const compEl = document.getElementById("popupAiJobCompany");
  const badgeEl = document.getElementById("popupAiAtsBadge");
  const barEl = document.getElementById("popupAiScoreBar");
  const pillsEl = document.getElementById("popupAiKeywordPills");

  try {
    const tab = await getActiveTab();
    if (!tab?.id) {
      if (titleEl) titleEl.textContent = "No active tab";
      return;
    }

    if (titleEl) titleEl.textContent = "Extracting job details...";
    chrome.tabs.sendMessage(tab.id, { type: "jobxapply:extractJD" }, (res) => {
      if (chrome.runtime.lastError || !res || !res.ok) {
        const titleParts = (tab.title || "").split(/[-|–—:]/);
        popupActiveJob = {
          title: titleParts[0]?.trim() || "Target Role",
          company: titleParts[1]?.trim() || "Company",
          description: tab.title || "",
          location: "",
          url: tab.url || ""
        };
      } else {
        popupActiveJob = {
          title: res.title || "Target Role",
          company: res.company || "Company",
          description: res.description || "",
          location: res.location || "",
          url: res.url || tab.url || ""
        };
      }

      if (titleEl) titleEl.textContent = popupActiveJob.title;
      if (compEl) compEl.textContent = popupActiveJob.company + (popupActiveJob.location ? " • " + popupActiveJob.location : "");

      const jdText = popupActiveJob.description || (popupActiveJob.title + " " + popupActiveJob.company);
      const matchResult = JDMatcher.matchJD(jdText, popupActiveProfile);
      const atsScore = matchResult.score || 75;

      if (badgeEl) {
        badgeEl.textContent = `ATS ${atsScore}%`;
        badgeEl.style.borderColor = atsScore >= 75 ? "#2fddc4" : (atsScore >= 50 ? "#f5a623" : "#ff5c5c");
        badgeEl.style.color = atsScore >= 75 ? "#2fddc4" : (atsScore >= 50 ? "#f5a623" : "#ff5c5c");
      }
      if (barEl) {
        barEl.style.width = `${atsScore}%`;
      }

      if (pillsEl) {
        pillsEl.innerHTML = "";
        const matchedPills = (matchResult.matched || []).slice(0, 4).map(kw =>
          `<span style="background:rgba(47,221,196,0.15); color:#2fddc4; padding:1px 5px; border-radius:3px; font-weight:600;">✓ ${kw}</span>`
        ).join("");
        const missingPills = (matchResult.missing || []).slice(0, 3).map(kw =>
          `<span style="background:rgba(245,166,35,0.15); color:#f5a623; padding:1px 5px; border-radius:3px; font-weight:600;">+ ${kw}</span>`
        ).join("");
        pillsEl.innerHTML = (matchedPills || missingPills) ? (matchedPills + missingPills) : '<span style="color:rgba(244,247,255,0.4);">Keywords analyzed.</span>';
      }
    });
  } catch (e) {
    console.error("loadPopupActiveJobAi error", e);
  }
}

function getPopupTailoredProfile() {
  const p = { ...popupActiveProfile };
  const jdText = popupActiveJob.description || (popupActiveJob.title + " " + popupActiveJob.company);
  const extracted = JDMatcher.extractKeywordsFromJD(jdText);
  const highPriority = (extracted?.highPriority || []).slice(0, 5);

  let existingSkills = Array.isArray(p.skills) ? [...p.skills] : (typeof p.skills === "string" ? p.skills.split(",").map(s => s.trim()) : []);
  const lowerExisting = new Set(existingSkills.map(s => s.toLowerCase()));
  highPriority.forEach(hp => {
    if (!lowerExisting.has(hp.toLowerCase())) {
      existingSkills.push(hp);
    }
  });
  p.skills = existingSkills;
  if (popupActiveJob.title && popupActiveJob.title !== "Target Role") {
    p.targetRole = popupActiveJob.title;
  }
  return p;
}

function handlePopupDownloadResume() {
  const tailored = getPopupTailoredProfile();
  const safeName = (tailored.fullName || tailored.name || "Resume").replace(/[^a-zA-Z0-9_-]/g, "_");
  const jobSuffix = (popupActiveJob.company || "Job").replace(/[^a-zA-Z0-9_-]/g, "_");
  const filename = `${safeName}_${jobSuffix}_Resume.pdf`;

  downloadResumePdf(tailored, filename);
  setStatus("Downloaded tailored resume PDF!", "success");
}

async function handlePopupAttachResume() {
  const statusEl = document.getElementById("popupAiAttachStatus");
  if (statusEl) statusEl.textContent = "Attaching tailored resume to portal...";

  try {
    const tab = await getActiveTab();
    if (!tab?.id) {
      if (statusEl) statusEl.textContent = "No active tab found.";
      return;
    }

    const tailored = getPopupTailoredProfile();
    const safeName = (tailored.fullName || tailored.name || "Resume").replace(/[^a-zA-Z0-9_-]/g, "_");
    const jobSuffix = (popupActiveJob.company || "Job").replace(/[^a-zA-Z0-9_-]/g, "_");
    const filename = `${safeName}_${jobSuffix}_Resume.pdf`;

    const pdfBytes = buildResumePdf(tailored);
    let binary = "";
    const len = pdfBytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(pdfBytes[i]);
    }
    const fileDataBase64 = btoa(binary);

    chrome.tabs.sendMessage(tab.id, {
      type: "jobxapply:injectResumeFile",
      fileData: fileDataBase64,
      fileName: filename,
      mimeType: "application/pdf"
    }, (res) => {
      if (chrome.runtime.lastError) {
        if (statusEl) statusEl.textContent = "Error: " + chrome.runtime.lastError.message;
        return;
      }
      if (res?.ok) {
        if (statusEl) statusEl.textContent = `✓ Attached ${filename}!`;
        setStatus(`Attached ${filename} to page form!`, "success");
      } else {
        if (statusEl) statusEl.textContent = res?.error || "No file upload inputs found";
        setStatus(res?.error || "Could not attach file", "warn");
      }
    });
  } catch (err) {
    if (statusEl) statusEl.textContent = "Attach error: " + err.message;
  }
}

function handlePopupGenerateCoverLetter() {
  const outputEl = document.getElementById("popupAiCoverOutput");
  const tailored = getPopupTailoredProfile();
  const jdText = popupActiveJob.description || (popupActiveJob.title + " " + popupActiveJob.company);

  const letterText = CoverLetterEngine.generateCoverLetter(tailored, {
    companyName: popupActiveJob.company || "Hiring Team",
    jobTitle: popupActiveJob.title || "Software Engineer",
    template: "technical",
    jdText: jdText
  });

  if (outputEl) outputEl.value = letterText;
  setStatus("Generated cover letter!", "success");
}

function handlePopupCopyCoverLetter() {
  const text = document.getElementById("popupAiCoverOutput")?.value || "";
  if (!text) {
    setStatus("Generate cover letter first", "warn");
    return;
  }
  navigator.clipboard.writeText(text);
  setStatus("Copied cover letter!", "success");
}

function handlePopupDownloadCoverLetter() {
  const text = document.getElementById("popupAiCoverOutput")?.value || "";
  if (!text) {
    setStatus("Generate cover letter first", "warn");
    return;
  }
  const comp = (popupActiveJob.company || "Company").replace(/[^a-zA-Z0-9_-]/g, "_");
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Cover_Letter_${comp}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  setStatus("Downloaded cover letter!", "success");
}

// ── Init ────────────────────────────────────────────────────────────────────
(async function init() {
  setupTabs();

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "jobxapply:profileUpdated") {
      checkAuthState();
    }
  });

  await loadPortalInfo();
  await checkAuthState();
  await detectActiveWebSession();

  document.getElementById("popupAiDownloadResumeBtn")?.addEventListener("click", handlePopupDownloadResume);
  document.getElementById("popupAiAttachResumeBtn")?.addEventListener("click", handlePopupAttachResume);
  document.getElementById("popupAiGenCoverBtn")?.addEventListener("click", handlePopupGenerateCoverLetter);
  document.getElementById("popupAiCopyCoverBtn")?.addEventListener("click", handlePopupCopyCoverLetter);
  document.getElementById("popupAiDownloadCoverBtn")?.addEventListener("click", handlePopupDownloadCoverLetter);

  document.getElementById("loginPasscodeBtn")?.addEventListener("click", handleDirectLogin);
  document.getElementById("loginPasscodeInput")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") handleDirectLogin();
  });
  document.getElementById("loginGoogleBtn")?.addEventListener("click", handleGoogleWebLogin);
  document.getElementById("loadTestProfileBtn")?.addEventListener("click", loadTestProfile);

  document.getElementById("apply")?.addEventListener("click", doAutofill);
  document.getElementById("quickLogBtn")?.addEventListener("click", () => logApplication());
  
  document.getElementById("manualLogBtn")?.addEventListener("click", () => {
    const company = document.getElementById("trackerCompanyInput")?.value?.trim();
    const role = document.getElementById("trackerRoleInput")?.value?.trim();
    const status = document.getElementById("trackerStatusSelect")?.value || "Applied";
    logApplication(company, role, status);
  });

  document.getElementById("openTrackerBtn")?.addEventListener("click", async () => {
    const activeTab = await getActiveTab();
    let base = "https://jobxapply.netlify.app";
    if (activeTab?.url && (activeTab.url.includes("localhost:") || activeTab.url.includes("127.0.0.1:"))) {
      try {
        const u = new URL(activeTab.url);
        base = `${u.protocol}//${u.host}`;
      } catch (e) {}
    }
    chrome.tabs.create({ url: `${base}/tracker.html` });
  });

  const triggerSidePanel = () => {
    chrome.runtime.sendMessage({ type: "jobxapply:openSidePanel" }, (res) => {
      if (res?.ok) {
        window.close();
      }
    });
  };

  document.getElementById("openSidePanelBtn")?.addEventListener("click", triggerSidePanel);
  document.getElementById("openWorkspaceBtn")?.addEventListener("click", triggerSidePanel);

  document.getElementById("editProfile")?.addEventListener("click", () => {
    chrome.runtime.openOptionsPage
      ? chrome.runtime.openOptionsPage()
      : chrome.tabs.create({ url: chrome.runtime.getURL("profile.html") });
  });

  document.getElementById("syncCloud")?.addEventListener("click", async () => {
    await syncFromCloud();
    await syncToWebTab();
  });
  document.getElementById("syncWebTabBtn")?.addEventListener("click", syncToWebTab);
  document.getElementById("disconnectBtn")?.addEventListener("click", handleDisconnect);
})();
