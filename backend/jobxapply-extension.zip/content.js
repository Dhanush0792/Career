// Immediately stamp active marker on authorized JobXApply / CareerBridge web pages
try {
  if (typeof document !== 'undefined' && document.documentElement) {
    const isApp = (typeof window !== 'undefined' && (
      (window.location.protocol === 'file:' && (window.location.href.toLowerCase().includes('careerbridge') || window.location.href.toLowerCase().includes('jobxapply'))) ||
      (window.location.origin && (
        window.location.origin.includes('localhost') ||
        window.location.origin.includes('127.0.0.1') ||
        window.location.origin.includes('jobxapply') ||
        window.location.origin.includes('careerbridge') ||
        window.location.origin.includes('careerhub') ||
        window.location.origin.endsWith('.netlify.app') ||
        window.location.origin.endsWith('.vercel.app') ||
        window.location.origin.endsWith('.onrender.com') ||
        window.location.origin.endsWith('.github.io')
      ))
    ));
    if (isApp) {
      document.documentElement.setAttribute('data-jobxapply-extension', 'active');
      window.__JOBXAPPLY_EXTENSION_ACTIVE__ = true;
      window.dispatchEvent(new CustomEvent('jobxapply:pongExtension', { detail: { version: '1.0.0', active: true } }));
      window.postMessage({ type: 'JOBXAPPLY_EXTENSION_PONG', active: true }, '*');
    }
  }
} catch (e) {}

// Enhanced content script: heuristic field matching and floating autofill button

const FIELD_ALIASES = {
  fullname: ["fullname", "full name", "applicant name", "candidate name", "candidate's name", "your name", "full_name", "applicant_name", "cand_name", "complete name", "legal name", "legal full name", "first and last name", "first & last name", "name"],
  firstname: ["first", "firstname", "given name", "first name", "fname", "first_name", "forename", "legal first name", "preferred first name"],
  middlename: ["middle", "middlename", "middle name", "mname", "middle_name", "legal middle name"],
  lastname: ["last", "lastname", "surname", "family name", "last name", "lname", "last_name", "legal last name"],
  age: ["age", "current age", "age in years", "applicant age"],
  dob: ["dob", "date of birth", "birthdate", "birthday", "birth date", "d.o.b", "d.o.b.", "date_of_birth"],
  dob_day: ["birth day", "dob day", "day of birth", "day (dob)", "birthdate day", "dd", "dob_dd", "dob_day"],
  dob_month: ["birth month", "dob month", "month of birth", "month (dob)", "birthdate month", "mm", "dob_mm", "dob_month"],
  dob_year: ["birth year", "dob year", "year of birth", "year (dob)", "birthdate year", "yyyy", "dob_yyyy", "dob_year"],
  gender: ["gender", "sex", "gender identity"],
  fathername: ["father's name", "father name", "guardian name", "father", "parent name", "fathers name", "father_name"],
  mothername: ["mother's name", "mother name", "mother", "mothers name", "mother_name"],
  email: ["email", "email address", "e-mail", "e-mail address", "user email", "primary email", "email_address", "cand_email", "applicant email", "electronic mail"],
  phone: ["phone", "phone number", "mobile", "mobile number", "telephone", "cell", "cell phone", "contact number", "primary phone", "cand_phone", "applicant phone", "contact no", "mobile no", "phone no", "cell number"],
  phonecode: ["phone code", "country code", "country/region code", "dial code", "calling code", "phone prefix", "isd code", "dialling code", "std code"],
  address: ["address", "street", "address1", "address line 1", "residential address", "permanent address", "current address", "street address", "line 1", "house no"],
  city: ["city", "town", "district", "current city", "current location", "location", "present location", "present city", "residential city", "where are you located", "city, state", "base location"],
  state: ["state", "province", "region", "state/province", "state / province"],
  country: ["country", "nation", "citizenship country", "country/region", "nationality"],
  zip: ["zip", "postal", "postal code", "zipcode", "zip code", "pin", "pincode", "pin code", "area code"],
  headline: ["headline", "professional headline", "title", "job title", "profile title"],
  summary: ["summary", "about", "about me", "bio", "description", "profile summary", "personal summary", "executive summary", "career objective", "objective"],
  education: ["education", "qualifications", "degree", "highest qualification", "academic background"],
  college: ["college", "university", "institution", "institute name", "school/university", "college/university"],
  experience: ["experience", "work experience", "employment", "professional experience", "past experience"],
  skills: ["skills", "skillset", "key skills", "technical skills", "core skills", "competencies"],
  linkedin: ["linkedin", "linked in", "linkedin profile", "linkedin url", "linkedin link", "urls[linkedin]"],
  github: ["github", "git hub", "github url", "github profile", "github link", "urls[github]"],
  portfolio: ["portfolio", "website", "site", "personal website", "portfolio url", "portfolio link", "web site", "urls[portfolio]", "urls[other]"],
  resume: ["resume", "cv", "curriculum vitae", "upload resume", "attach resume", "upload cv"],
  targetrole: ["role", "target role", "position", "designation", "desired role", "applied position", "job profile", "applying for"],
  portalpassword: ["choose password", "password", "create password", "new password", "portal password", "account password"],
  alternativeemail: ["alternative email", "alt email", "alternate email", "secondary email", "alt_email"],
  pincode: ["pincode", "pin code", "postal code", "zip", "zip code", "area pincode"],
  maritalstatus: ["marital status", "marital", "marriage status", "single/married", "marital_status"],
  employmentstatus: ["employment status", "employment", "job status", "current status", "current employment status", "work status"],
  expectedsalary: ["expected salary", "expected package", "salary expectation", "expected ctq", "expected ctc", "desired salary", "expected remuneration", "expected fixed salary"],
  currentsalary: ["current salary", "current package", "current ctc", "present salary", "present ctc", "current fixed salary"],
  handicapped: ["handicapped", "physically handicapped", "disability", "disabled", "special ability", "pwd", "person with disability"],
  healthissues: ["health issues", "medical history", "health status", "medical conditions", "major illness"],
  targetroles: ["target roles", "preferred roles", "desired roles"],
  coverletterdraft: ["cover letter", "letter", "letter of intent", "cover_letter"],
  otherdocuments: ["other documents", "supporting documents", "additional documents", "certificates"],
  noticeperiod: ["notice period", "notice", "days to join", "joining time", "availability to join", "notice days", "notice period in days", "availability"],
  totalexperience: ["total experience", "years of experience", "work experience", "experience in years", "experience (years)", "total work experience", "relevant experience", "total years of experience"],
  currentcompany: ["current company", "current employer", "organization", "company", "present employer", "employer name", "firm", "org", "current organization"],
  
  // Behavioral & Application Q&A Vault
  q_why_hire: ["why should we hire you", "why hire", "why are you a good fit", "why fit for this role", "what makes you a good fit", "why you are the best candidate", "why should you be considered", "why do you think you are suitable"],
  q_why_company: ["why do you want to work here", "why our company", "why join us", "why this company", "what interests you about this role", "why do you want to join", "why work at", "motivation to join"],
  q_achievement: ["greatest achievement", "proudest project", "key accomplishment", "significant project", "major achievement", "most proud of", "key project"],
  q_challenge: ["challenge you overcame", "difficult technical challenge", "conflict you resolved", "handled a setback", "problem you solved", "overcame an obstacle", "complex situation"],
  q_strengths_weaknesses: ["strengths and weaknesses", "greatest strength", "area of improvement", "core strengths", "areas for improvement"],
  q_leadership: ["leadership experience", "demonstrated initiative", "led a project", "mentored someone", "leadership", "taking initiative"],
  
  edu10_school: ["10th school", "10th board school", "ssc school", "matriculation school", "school name (10", "class x school", "class 10 school", "secondary school name", "high school name", "10th standard school", "standard 10 school"],
  edu10_board: ["10th board", "ssc board", "matriculation board", "class x board", "class 10 board", "secondary board", "secondary school board", "10th standard board"],
  edu10_year: ["10th passing year", "10th year", "ssc passing year", "matric_year", "matric year", "matriculation passing year", "class x passing year", "class 10 passing year", "year of passing (10", "year of completion (10", "secondary passing year", "year of passing 10th"],
  edu10_cgpa: ["10th cgpa", "10th percentage", "10th marks", "ssc cgpa", "ssc percentage", "ssc marks", "matriculation marks", "class x marks", "class x cgpa", "class 10 cgpa", "class 10 percentage", "10th grade"],
  
  edu12_school: ["12th school", "12th board school", "hsc school", "intermediate school", "school name (12", "class xii school", "class 12 school", "higher secondary school name", "senior secondary school name", "intermediate college", "junior college", "puc college", "diploma college", "diploma institute", "pre-university college"],
  edu12_board: ["12th board", "hsc board", "intermediate board", "class xii board", "class 12 board", "higher secondary board", "senior secondary board", "intermediate board name", "puc board", "state board intermediate"],
  edu12_year: ["12th passing year", "12th year", "hsc passing year", "intermediate passing year", "class xii passing year", "class 12 passing year", "year of passing (12", "year of completion (12", "higher secondary passing year", "diploma completion year"],
  edu12_cgpa: ["12th cgpa", "12th percentage", "12th marks", "hsc cgpa", "hsc percentage", "hsc marks", "intermediate marks", "intermediate cgpa", "class xii marks", "class xii cgpa", "class 12 cgpa", "class 12 percentage", "diploma percentage", "diploma marks"],
  
  edugrad_college: ["graduation college", "graduation university", "undergraduate college", "undergraduate university", "degree college", "bachelor college", "bachelor university", "college name", "university name", "institute of graduation", "ug college", "ug university"],
  edugrad_degree: ["graduation degree", "undergraduate degree", "bachelor degree", "degree name", "bachelors degree", "ug degree", "first degree", "b.tech", "b.e", "b.sc", "bca"],
  edugrad_stream: ["graduation stream", "graduation branch", "graduation discipline", "graduation major", "undergraduate major", "undergraduate stream", "undergraduate branch", "degree major", "degree stream", "degree branch", "branch/discipline", "specialization", "field of study"],
  edugrad_year: ["graduation passing year", "graduation year", "undergraduate passing year", "undergraduate year", "degree passing year", "degree year", "year of passing", "passing year", "completion year", "graduation date", "ug passing year"],
  edugrad_cgpa: ["graduation cgpa", "graduation percentage", "graduation marks", "undergraduate cgpa", "undergraduate percentage", "degree cgpa", "degree percentage", "gpa", "cgpa", "aggregate marks", "percentage of marks", "undergraduate gpa", "ug percentage"],
  edugrad_pursuing: ["graduation pursuing", "currently studying", "current student"],
  
  edupg_college: ["pg college", "pg university", "post graduate college", "post graduate university", "post-graduate college", "postgraduate university", "master college", "masters university"],
  edupg_degree: ["pg degree", "post graduate degree", "post-graduate degree", "postgraduate degree", "master degree", "master's degree", "m.tech", "m.s", "mba"],
  edupg_stream: ["pg stream", "pg branch", "pg discipline", "pg major", "post graduate major", "post graduate stream", "post graduate branch", "masters specialization"],
  edupg_year: ["pg passing year", "pg year", "post graduate passing year", "post graduate year", "masters passing year"],
  edupg_cgpa: ["pg cgpa", "pg percentage", "pg marks", "post graduate cgpa", "post graduate percentage", "masters cgpa"],
  edupg_pursuing: ["pg pursuing"],
  
  edumasters_college: ["masters college", "masters university", "master college", "master university"],
  edumasters_degree: ["masters degree", "master degree", "master of"],
  edumasters_stream: ["masters stream", "masters branch", "masters discipline", "masters major"],
  edumasters_year: ["masters passing year", "masters year", "master passing year"],
  edumasters_cgpa: ["masters cgpa", "masters percentage", "masters marks", "master cgpa"],
  edumasters_pursuing: ["masters pursuing"],
  
  eduphd_college: ["phd college", "phd university", "doctorate college", "doctorate university"],
  eduphd_degree: ["phd degree", "doctorate degree"],
  eduphd_stream: ["phd stream", "phd branch", "phd discipline", "phd major", "doctorate major"],
  eduphd_year: ["phd passing year", "phd year", "doctorate passing year"],
  eduphd_cgpa: ["phd cgpa", "phd percentage", "phd marks", "doctorate cgpa"],
  eduphd_pursuing: ["phd pursuing"],

  // Master Screening & Compliance Vault Aliases
  workauthstatus: ["work authorization", "authorized to work", "legally authorized to work", "work eligibility", "are you legally authorized", "right to work"],
  requiresponsorship: ["require sponsorship", "visa sponsorship", "future sponsorship", "require visa sponsorship", "sponsorship now or in the future", "will you require sponsorship", "immigration sponsorship"],
  visatype: ["visa type", "current visa", "citizenship status", "visa status", "immigration status", "work permit"],
  noticeperioddays: ["notice period in days", "days of notice", "notice period", "joining time", "availability to join", "how many days notice"],
  willingtorelocate: ["willing to relocate", "relocation", "open to relocation", "relocate", "are you willing to relocate"],
  willingtotravel: ["willing to travel", "travel percentage", "travel willingness", "open to travel", "ability to travel"],
  earlieststartdate: ["earliest start date", "available start date", "start date", "availability date", "when can you start"],
  currentfixedsalary: ["current fixed salary", "current base salary", "current fixed", "current fixed ctc", "base salary"],
  currentsalarycurrency: ["current salary currency", "currency"],
  expectedfixedsalary: ["expected fixed salary", "expected base salary", "expected fixed", "expected fixed ctc"],
  expectedsalarycurrency: ["expected salary currency", "target currency"],
  salarynegotiable: ["salary negotiable", "compensation flexible", "negotiable", "salary expectation flexible"],
  genderidentity: ["gender identity", "gender", "self-identify gender", "what is your gender"],
  veteranstatus: ["veteran status", "veteran", "military status", "protected veteran status", "are you a veteran"],
  disabilitystatus: ["disability status", "disability", "voluntary self-identification of disability", "do you have a disability"],
  raceethnicity: ["race", "ethnicity", "race/ethnicity", "hispanic or latino", "ethnic background"],
  legallyauthorized: ["legally authorized", "authorized to work in", "eligible to work in"],
  previouslyemployedhere: ["previously employed", "worked here before", "former employee", "ever worked for", "previous employment at"],
  hasrelativeshere: ["relatives employed", "relatives working", "family member at company", "any relatives working here"],
  securityclearance: ["security clearance", "clearance level", "active clearance", "government clearance"]
};

// Built-in ATS portal mapping definitions for content script execution
const ATS_PORTAL_RULES = [
  { match: /linkedin\.com/i, portal: "LinkedIn" },
  { match: /naukri\.com/i, portal: "Naukri" },
  { match: /wellfound\.com|angel\.co/i, portal: "Wellfound" },
  { match: /indeed\.com/i, portal: "Indeed" },
  { match: /boards\.greenhouse\.io|job-boards\.greenhouse\.io/i, portal: "Greenhouse" },
  { match: /lever\.co|jobs\.lever\.co/i, portal: "Lever" },
  { match: /myworkdayjobs\.com|workday\.com/i, portal: "Workday" },
  { match: /ashbyhq\.com/i, portal: "Ashby" }
];

const ATS_PORTAL_MAPS = {
  LinkedIn: {
    fullName: "input[aria-label*='Full name' i], input[placeholder*='Full name' i], input[name*='fullName' i]",
    firstName: "input[aria-label*='First name' i], input[placeholder*='First name' i], input[name*='firstName' i]",
    lastName: "input[aria-label*='Last name' i], input[placeholder*='Last name' i], input[name*='lastName' i]",
    email: "input[aria-label*='Email' i], input[placeholder*='Email' i], input[type='email']",
    phone: "input[aria-label*='Phone' i], input[placeholder*='Phone' i], input[name*='phone' i]",
    linkedin: "input[aria-label*='LinkedIn' i], input[placeholder*='LinkedIn' i]",
    resume: "input[type='file'], input[accept*='pdf'], input[accept*='doc']"
  },
  Naukri: {
    fullName: "input[placeholder*='Name' i], input[name*='name' i], input[aria-label*='Name' i]",
    email: "input[placeholder*='Email' i], input[name*='email' i], input[type='email']",
    phone: "input[placeholder*='Mobile' i], input[name*='mobile' i], input[name*='phone' i]",
    resume: "input[type='file'][name*='resume' i], input[type='file']",
    college: "input[placeholder*='College' i], input[name*='college' i]"
  },
  Wellfound: {
    fullName: "input[name*='name' i], input[placeholder*='name' i], input[aria-label*='name' i]",
    email: "input[name*='email' i], input[type='email']",
    phone: "input[name*='phone' i], input[name*='mobile' i]",
    resume: "input[type='file']",
    linkedin: "input[name*='linkedin' i], input[placeholder*='linkedin' i]",
    portfolio: "input[name*='portfolio' i], input[placeholder*='portfolio' i]"
  },
  Indeed: {
    fullName: "input[id*='name' i], input[name*='name' i], input[placeholder*='name' i]",
    email: "input[type='email'], input[id*='email' i], input[name*='email' i]",
    phone: "input[type='tel'], input[id*='phone' i], input[name*='phone' i]",
    resume: "input[type='file']",
    city: "input[id*='city' i], input[name*='city' i]",
    country: "input[id*='country' i], input[name*='country' i]"
  },
  Greenhouse: {
    fullName: "#first_name, #last_name, #name, input[name*='name' i], input[name*='first_name' i]",
    email: "#email, input[name*='email' i], input[type='email']",
    phone: "#phone, input[name*='phone' i], input[type='tel']",
    resume: "#resume_file, input[type='file']",
    linkedin: "input[placeholder*='LinkedIn' i], input[name*='linkedin' i]"
  },
  Lever: {
    fullName: "input[name='name'], input[name*='name' i]",
    email: "input[name='email'], input[type='email']",
    phone: "input[name='phone'], input[type='tel']",
    currentCompany: "input[name='org'], input[name*='org' i]",
    city: "input[name='location'], input[placeholder*='location' i]",
    linkedin: "input[name*='urls[LinkedIn]' i], input[name*='linkedin' i], input[placeholder*='linkedin' i]",
    github: "input[name*='urls[GitHub]' i], input[name*='github' i], input[placeholder*='github' i]",
    portfolio: "input[name*='urls[Portfolio]' i], input[name*='urls[Other]' i], input[placeholder*='portfolio' i], input[placeholder*='website' i]",
    resume: "input[type='file']"
  },
  Workday: {
    fullName: "input[data-automation-id*='legalName' i], input[data-automation-id*='name' i]",
    firstName: "input[data-automation-id*='firstName' i]",
    lastName: "input[data-automation-id*='lastName' i]",
    email: "input[data-automation-id*='email' i], input[type='email']",
    phone: "input[data-automation-id*='phone' i]",
    city: "input[data-automation-id*='city' i]",
    resume: "input[type='file']"
  },
  Ashby: {
    fullName: "input[name*='name' i], input[id*='name' i]",
    email: "input[type='email'], input[name*='email' i]",
    phone: "input[type='tel'], input[name*='phone' i]",
    linkedin: "input[placeholder*='LinkedIn' i], input[name*='linkedin' i]",
    github: "input[placeholder*='GitHub' i], input[name*='github' i]",
    portfolio: "input[placeholder*='website' i], input[placeholder*='portfolio' i]",
    resume: "input[type='file']"
  }
};

function getActivePortalMap() {
  const currentUrl = window.location.href || "";
  const rule = ATS_PORTAL_RULES.find(r => r.match.test(currentUrl));
  if (rule && ATS_PORTAL_MAPS[rule.portal]) {
    return { ...ATS_PORTAL_MAPS[rule.portal] };
  }
  return {};
}

let extensionEnabled = true;
chrome.storage.local.get("extensionEnabled", (res) => {
  if (res.extensionEnabled !== undefined) {
    extensionEnabled = res.extensionEnabled;
  }
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.extensionEnabled) {
    extensionEnabled = changes.extensionEnabled.newValue;
  }
});

const KNOWN_PORTALS = [
  "naukri", "linkedin", "wellfound", "angel.co", "indeed",
  "myworkdayjobs", "greenhouse", "lever", "icims", "smartrecruiters",
  "internshala", "ashbyhq", "workday", "taleo", "freshteam", "glassdoor",
  "monster", "rippling", "bamboohr"
];

function isJobPage() {
  const host = location.hostname.toLowerCase();
  
  const BLACKLISTED = [
    "google.", "bing.com", "yahoo.com", "duckduckgo.com", "baidu.com", "yandex.com",
    "chatgpt.com", "openai.com", "claude.ai", "github.com", "gitlab.com",
    "microsoft.com", "stripe.com", "paypal.com", "facebook.com", "instagram.com",
    "twitter.com", "x.com", "youtube.com", "wikipedia.org", "netflix.com",
    "amazon.", "flipkart.com", "reddit.com", "quora.com", "twitch.tv",
    "gmail.com", "outlook.com", "mail.google.com", "web.whatsapp.com",
    "onrender.com"
  ];
  
  if (BLACKLISTED.some(d => host === d || host.endsWith(d) || host.includes(d))) {
    return false;
  }
  
  // Whitelisted Tier 1 & 2 portals
  if (KNOWN_PORTALS.some(p => host.includes(p))) {
    return true;
  }

  // Universal Heuristic: Detect actual job application forms on ANY career site
  // Require explicit career/job context in URL or document title
  const pathname = location.pathname.toLowerCase();
  const title = (document.title || "").toLowerCase();
  const urlKeywords = [
    "/job", "/jobs", "/career", "/careers", "/apply", "/application", 
    "/opening", "/openings", "/vacancy", "/vacancies", "/position", "/positions",
    "/recruit", "/candidate", "/internship", "/employment", "/hire"
  ];
  const isJobContext = urlKeywords.some(kw => pathname.includes(kw)) || 
                       ["job application", "career opportunities", "apply for", "job opening"].some(kw => title.includes(kw));

  // Count candidate input fields (excluding hidden, submit, button, search inputs)
  const inputs = Array.from(document.querySelectorAll("input:not([type='hidden']):not([type='submit']):not([type='button']):not([type='search']), textarea, select"));
  const visibleInputs = inputs.filter(el => {
    const style = window.getComputedStyle(el);
    const isSearchInput = (el.name && /search|query|q\b/i.test(el.name)) || (el.id && /search|query|q\b/i.test(el.id)) || (el.getAttribute("role") === "searchbox");
    return style.display !== "none" && style.visibility !== "hidden" && el.type !== "hidden" && !isSearchInput;
  });

  // Verify presence of at least one dedicated job application signature field
  const hasJobFormSignature = inputs.some(el => {
    const attrs = [el.name, el.id, el.placeholder, el.getAttribute("aria-label"), el.className].filter(Boolean).join(" ").toLowerCase();
    const isFileInput = el.type === "file" && /resume|cv|curriculum/i.test(attrs);
    const isJobSpecificField = /resume|curriculum|portfolio|linkedin|github|experience|education|degree|qualification|notice[_\s]?period|work[_\s]?authorization|sponsorship|salary[_\s]?expectation/i.test(attrs);
    return isFileInput || isJobSpecificField;
  });

  // Must have career context AND at least 3 visible inputs AND at least 1 job signature field
  if (isJobContext && visibleInputs.length >= 2 && hasJobFormSignature) {
    return true;
  }

  // Or an application form with clear resume upload input and standard contact fields
  const hasResumeUpload = Array.from(document.querySelectorAll("input[type='file']")).some(el => {
    const attrs = [el.name, el.id, el.getAttribute("aria-label"), el.className].join(" ").toLowerCase();
    return /resume|cv|curriculum/i.test(attrs);
  });

  if (hasResumeUpload && visibleInputs.length >= 3) {
    return true;
  }

  return false;
}

function normalize(s) {
  return String(s || "")
    .toLowerCase()
    .replace(/[*::]/g, "") // Strip colons and asterisks
    .replace(/\s+/g, " ")   // Collapse extra whitespaces
    .trim();
}

function getElementLabelText(el) {
  if (!el) return "";
  const attrs = [
    el.getAttribute("aria-label"),
    el.getAttribute("placeholder"),
    el.getAttribute("name"),
    el.getAttribute("id")
  ].filter(Boolean).join(" ");
  
  let labelText = attrs;
  try {
    const id = el.getAttribute("id");
    if (id) {
      const label = document.querySelector(`label[for='${id}']`);
      if (label) labelText += " " + label.textContent;
    }
  } catch (e) {}
  
  const closestLabel = el.closest("label");
  if (closestLabel) {
    labelText += " " + closestLabel.textContent;
  } else if (el.parentElement) {
    labelText += " " + el.parentElement.textContent;
  }
  return labelText;
}

function scoreElementForKey(el, key) {
  if (!el) return 0;
  const normKey = String(key || "").toLowerCase();
  const checks = [];
  const attrs = [el.getAttribute("aria-label"), el.getAttribute("name"), el.getAttribute("id"), el.getAttribute("placeholder"), el.getAttribute("type")];
  for (const a of attrs) {
    checks.push(normalize(a));
  }
  // associated label text
  try {
    const id = el.getAttribute("id");
    if (id) {
      const label = document.querySelector(`label[for='${id}']`);
      if (label) checks.push(normalize(label.textContent));
    }
  } catch (e) {}
  let surrounding = "";
  const closestLabel = el.closest("label");
  if (closestLabel) {
    surrounding = normalize(closestLabel.textContent);
  } else {
    // Traverse up to 3 parent elements to find label text
    let curr = el.parentElement;
    let depth = 0;
    while (curr && depth < 3) {
      const text = normalize(curr.textContent || "");
      if (text && text.length > 2 && text.length < 250) {
        surrounding += " " + text;
      }
      curr = curr.parentElement;
      depth++;
    }
  }
  checks.push(surrounding);

  // Sibling lookup (especially for table cells or adjacent div labels)
  try {
    let sib = el.previousElementSibling;
    if (sib) checks.push(normalize(sib.textContent));
    let nextSib = el.nextElementSibling;
    if (nextSib) checks.push(normalize(nextSib.textContent));
    let parentSib = el.parentElement ? el.parentElement.previousElementSibling : null;
    if (parentSib) checks.push(normalize(parentSib.textContent));
    let parentNextSib = el.parentElement ? el.parentElement.nextElementSibling : null;
    if (parentNextSib) checks.push(normalize(parentNextSib.textContent));
  } catch (e) {}

  const combinedContext = checks.join(" ");

  // ── SEMANTIC DISQUALIFICATION GUARDS ──────────────────────────────────────
  // 1. Education fields MUST have explicit educational context in label/attributes
  const isEduKey = normKey.includes("edu") || normKey.includes("school") || normKey.includes("college") || normKey.includes("degree") || normKey.includes("cgpa") || normKey.includes("board");
  if (isEduKey) {
    const hasEduContext = /(school|college|university|institute|degree|cgpa|gpa|percentage|marks|board|matric|hsc|ssc|graduation|bachelor|master|phd|education|academic)/i.test(combinedContext);
    if (!hasEduContext) return 0;
    // An education institution field must NEVER claim a generic candidate name input
    const isGenericPersonalNameOnly = /^(full name|name|applicant name|candidate name|legal name)$/i.test(checks[0]) ||
                                      /^(name|applicant_name|candidate_name|full_name)$/i.test(el.name || "") ||
                                      /^(name|applicant_name|candidate_name|full_name)$/i.test(el.id || "");
    if (isGenericPersonalNameOnly && !/(school|college|university|institute)/i.test(el.name || "") && !/(school|college|university|institute)/i.test(el.id || "")) {
      return 0;
    }
  }

  // 2. Personal candidate name fields MUST NOT match company, school, or file inputs
  const isPersonalName = normKey === "fullname" || normKey === "firstname" || normKey === "lastname" || normKey === "middlename";
  if (isPersonalName) {
    const isNonPerson = /(company|organization|org|school|college|university|employer|firm|institute|file|resume|attachment)/i.test(combinedContext);
    if (isNonPerson) return 0;
  }

  // 3. Email fields MUST have email in input type or context
  if (normKey === "email" || normKey === "alternativeemail") {
    const isEmail = el.type === "email" || /email|e-mail/i.test(combinedContext);
    if (!isEmail) return 0;
  }

  // 4. Phone fields MUST have phone/mobile/tel in input type or context
  if (normKey === "phone" || normKey === "phonecode") {
    const isPhone = el.type === "tel" || /phone|mobile|telephone|contact no|cell/i.test(combinedContext);
    if (!isPhone) return 0;
  }

  // 5. Company / Employer fields MUST have company / organization context
  if (normKey === "currentcompany" || normKey === "company") {
    const isCompany = /company|organization|employer|org|firm|current employer/i.test(combinedContext);
    if (!isCompany) return 0;
  }

  // ── HEURISTIC SCORING ─────────────────────────────────────────────────────
  let maxScore = 0;
  const aliases = FIELD_ALIASES[normKey] || [];
  const GENERIC_SUBSTRINGS = new Set(["name", "id", "text", "input", "field", "txt", "data", "val", "no", "code", "num", "url", "org"]);

  for (const a of aliases) {
    const needle = normalize(a);
    for (const c of checks) {
      if (!c) continue;
      let score = 0;
      if (c === needle) {
        score = 10;
      } else if (c.includes(needle)) {
        // Disqualify if c simply matches a generic token inside another token
        if (needle.length < 5 && GENERIC_SUBSTRINGS.has(needle)) {
          // e.g. "name" inside "school name" shouldn't grant full 8 points to a personal name
          score = 0;
        } else {
          score = 8;
        }
      } else if (needle.includes(c)) {
        // Only count if c is NOT a generic short word
        if (c.length >= 5 && !GENERIC_SUBSTRINGS.has(c)) {
          score = 6;
        }
      }
      if (score > maxScore) {
        maxScore = score;
      }
    }
  }
  return maxScore;
}

function findBestElementForKey(key, claimedElements = new Set()) {
  const candidates = Array.from(document.querySelectorAll("input, textarea, select, [contenteditable='true']"));
  let best = null;
  let bestScore = 0;
  for (const el of candidates) {
    if (claimedElements.has(el)) continue; // Never overwrite already claimed elements!
    const score = scoreElementForKey(el, key);
    if (score > bestScore) {
      best = el;
      bestScore = score;
    }
  }
  const confidenceThreshold = 7; // Strict 70% minimum score threshold
  return bestScore >= confidenceThreshold ? best : null;
}

function fillConfirmationFields(originalEl, value) {
  const originalLabel = normalize(getElementLabelText(originalEl));
  if (!originalLabel) return;
  const inputs = Array.from(document.querySelectorAll("input, textarea"));
  for (const el of inputs) {
    if (el === originalEl) continue;
    const label = normalize(getElementLabelText(el));
    if (label.includes("confirm") || label.includes("retype") || label.includes("repeat") || label.includes("verify") || label.includes("re-type")) {
      if (originalLabel.includes("email") && label.includes("email")) {
        setValueRaw(el, value);
      }
      if (originalLabel.includes("password") && label.includes("password")) {
        setValueRaw(el, value);
      }
    }
  }
}

function setValueRaw(el, value) {
  if (!el) return false;
  if (el.isContentEditable) {
    el.focus();
    document.execCommand("selectAll", false, null);
    document.execCommand("insertText", false, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
    return true;
  }
  const tag = el.tagName?.toLowerCase();
  const type = normalize(el.getAttribute("type"));
  if (tag === "select") {
    const normVal = normalize(value);
    const options = Array.from(el.options || []);
    
    // 1. Try exact match first
    for (const opt of options) {
      const optText = normalize(opt.text);
      const optVal = normalize(opt.value);
      if (optText === normVal || optVal === normVal) {
        el.focus();
        el.value = opt.value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.blur();
        return true;
      }
    }
    
    // 2. Try exact match cleaned of non-alphanumeric chars
    const cleanVal = normVal.replace(/[^a-z0-9]/g, "");
    for (const opt of options) {
      const cleanText = normalize(opt.text).replace(/[^a-z0-9]/g, "");
      const cleanOptVal = normalize(opt.value).replace(/[^a-z0-9]/g, "");
      if (cleanText === cleanVal || cleanOptVal === cleanVal) {
        el.focus();
        el.value = opt.value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.blur();
        return true;
      }
    }

    // 3. Fallback to partial match (only if prefix matches or options contain value)
    for (const opt of options) {
      const optText = normalize(opt.text);
      if (optText.startsWith(normVal) || optText.includes(normVal) || normalize(opt.value).includes(normVal)) {
        el.focus();
        el.value = opt.value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.blur();
        return true;
      }
    }
    return false;
  }
  if (type === "radio") {
    const normVal = normalize(String(value));
    const isAffirmative = normVal === "yes" || normVal === "true" || normVal === "authorized" || normVal === "1";
    const isNegative = normVal === "no" || normVal === "false" || normVal === "not authorized" || normVal === "0";
    
    // Find all radios in the same group or fieldset
    let radios = [];
    if (el.name) {
      try {
        radios = Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(el.name)}"]`));
      } catch (e) {}
    }
    if (!radios.length) {
      const fieldset = el.closest("fieldset, [role='radiogroup'], .form-group, .field, div");
      if (fieldset) {
        radios = Array.from(fieldset.querySelectorAll('input[type="radio"]'));
      }
    }
    if (!radios.length) radios = [el];

    let chosenRadio = null;
    for (const r of radios) {
      const rVal = normalize(r.value || "");
      let lText = "";
      try {
        const rId = r.id ? CSS.escape(r.id) : null;
        const label = (rId ? document.querySelector(`label[for="${rId}"]`) : null) || r.closest("label") || r.parentElement;
        lText = normalize(label?.textContent || "");
      } catch (e) {}

      if (rVal === normVal || lText === normVal || (normVal.length > 2 && (lText.includes(normVal) || rVal.includes(normVal)))) {
        chosenRadio = r;
        break;
      }
      if (isAffirmative && (rVal === "yes" || lText === "yes" || lText.startsWith("yes") || rVal === "1" || lText.includes("authorized") || lText.includes("agree"))) {
        chosenRadio = r;
        break;
      }
      if (isNegative && (rVal === "no" || lText === "no" || lText.startsWith("no") || rVal === "0" || lText.includes("decline") || lText.includes("do not") || lText.includes("not authorized"))) {
        chosenRadio = r;
        break;
      }
    }

    const targetRadio = chosenRadio || el;
    targetRadio.focus();
    targetRadio.checked = true;
    targetRadio.dispatchEvent(new Event("pointerdown", { bubbles: true, composed: true }));
    targetRadio.dispatchEvent(new Event("mousedown", { bubbles: true, composed: true }));
    targetRadio.dispatchEvent(new Event("click", { bubbles: true, composed: true }));
    targetRadio.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    targetRadio.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    targetRadio.blur();
    return true;
  }

  if (type === "checkbox") {
    const boolVal = Boolean(value) && String(value).toLowerCase() !== "false" && String(value).toLowerCase() !== "no";
    el.focus();
    if (el.checked !== boolVal) {
      el.click();
    }
    el.checked = boolVal;
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    el.blur();
    return true;
  }

  // Standard text, textarea, and numeric inputs
  el.focus();
  el.dispatchEvent(new Event("pointerdown", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("mousedown", { bubbles: true, composed: true }));
  try {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) {
      descriptor.set.call(el, value);
    } else {
      el.value = value;
    }
  } catch (e) {
    try { el.value = value; } catch (err) {}
  }
  // Dispatch complete synthetic event cascade to satisfy React, Angular, Vue, and vanilla DOM listeners
  el.dispatchEvent(new Event("keydown", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("keypress", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("keyup", { bubbles: true, composed: true }));
  el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  el.blur();
  return true;
}

function setValue(el, value) {
  if (!el) return false;
  const tag = el.tagName?.toLowerCase();
  const role = el.getAttribute("role");
  const cls = String(el.className || "");
  
  if (tag !== "select" && (role === "combobox" || role === "listbox" || cls.includes("select") || cls.includes("dropdown") || cls.includes("control"))) {
    el.focus();
    el.dispatchEvent(new Event("pointerdown", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("mousedown", { bubbles: true, composed: true }));
    el.click();
    setTimeout(() => {
      const optionItems = Array.from(document.querySelectorAll("li, [role='option'], .sapMSelectItem, .dropdown-item, [class*='option'], div[id*='react-select']"));
      const normVal = normalize(value);
      let matchedOpt = null;
      for (const opt of optionItems) {
        const text = normalize(opt.textContent);
        if (text === normVal || text.startsWith(normVal) || (normVal.length > 2 && text.includes(normVal))) {
          matchedOpt = opt;
          break;
        }
      }
      if (matchedOpt) {
        matchedOpt.dispatchEvent(new Event("pointerdown", { bubbles: true, composed: true }));
        matchedOpt.dispatchEvent(new Event("mousedown", { bubbles: true, composed: true }));
        matchedOpt.click();
      } else {
        el.click();
      }
    }, 150);
    return true;
  }
  
  const filled = setValueRaw(el, value);
  if (filled) {
    fillConfirmationFields(el, value);
  }
  return filled;
}

function getPhoneCode(profile) {
  const phone = String(profile.phone || "");
  if (phone.startsWith("+")) {
    const match = phone.match(/^\+(\d+)/);
    if (match) return match[1];
  }
  const country = String(profile.country || "").toLowerCase();
  const address = String(profile.address || "").toLowerCase();
  if (country.includes("india") || address.includes("india")) return "91";
  if (country.includes("united states") || country.includes("usa") || country.includes("us")) return "1";
  if (country.includes("united kingdom") || country.includes("uk")) return "44";
  return "";
}

function getParsedLocationField(profile, fieldKey) {
  const profileLower = {};
  for (const [k, v] of Object.entries(profile || {})) {
    profileLower[k.toLowerCase()] = v;
  }
  const rawVal = profileLower[fieldKey.toLowerCase()];
  if (rawVal && String(rawVal).trim()) return String(rawVal).trim();
  
  const locStr = String(profileLower["address"] || profileLower["location"] || "");
  if (!locStr) return "";
  
  const parts = locStr.split(",").map(s => s.trim());
  if (parts.length === 1) {
    if (fieldKey.toLowerCase() === "country") return parts[0];
    if (fieldKey.toLowerCase() === "city") return parts[0];
  } else if (parts.length === 2) {
    if (fieldKey.toLowerCase() === "city") return parts[0];
    if (fieldKey.toLowerCase() === "country") return parts[1];
  } else if (parts.length >= 3) {
    if (fieldKey.toLowerCase() === "city") return parts[0];
    if (fieldKey.toLowerCase() === "state") return parts[1];
    if (fieldKey.toLowerCase() === "country") return parts[parts.length - 1];
  }
  return "";
}

function getPortalPassword(profile) {
  const profileLower = {};
  for (const [k, v] of Object.entries(profile || {})) {
    profileLower[k.toLowerCase()] = v;
  }
  if (profileLower["portalpassword"] && String(profileLower["portalpassword"]).trim()) {
    return String(profileLower["portalpassword"]).trim();
  }
  if (profileLower["password"] && String(profileLower["password"]).trim()) {
    return String(profileLower["password"]).trim();
  }
  
  const host = location.hostname.toLowerCase();
  let company = "Portal";
  const match = host.match(/([a-z0-9\-]+)\.(com|org|net|co|io|edu|eu|in)/);
  if (match) {
    company = match[1].charAt(0).toUpperCase() + match[1].slice(1);
  }
  return `JobXApply@${company}2026!`;
}

function buildAutofillPayload(profile, requestedFields) {
  const fields = requestedFields && requestedFields.length ? requestedFields : Object.keys(profile || {});
  const payload = {};
  const profileLower = {};
  for (const [k, v] of Object.entries(profile || {})) {
    profileLower[k.toLowerCase()] = v;
  }
  
  // Make sure password, city, state, country, phonecode keys are included in the fields list
  const activeFields = new Set(fields.map(f => normalize(f).replace(/\s+/g, "")));
  activeFields.add("portalpassword");
  activeFields.add("city");
  activeFields.add("state");
  activeFields.add("country");
  activeFields.add("phonecode");
  activeFields.add("alternativeemail");
  activeFields.add("pincode");
  activeFields.add("maritalstatus");
  activeFields.add("employmentstatus");
  activeFields.add("expectedsalary");
  activeFields.add("handicapped");
  activeFields.add("healthissues");
  // Multi-part split fields: dob -> dob_day, dob_month, dob_year
  activeFields.add("dob_day");
  activeFields.add("dob_month");
  activeFields.add("dob_year");
  activeFields.add("firstname");
  activeFields.add("lastname");

  // Parse DOB into components if present
  let dobDay = "", dobMonth = "", dobYear = "";
  const rawDob = String(profileLower["dob"] || profile["dob"] || "").trim();
  if (rawDob) {
    const dobMatch = rawDob.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/) || rawDob.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
    if (dobMatch) {
      if (dobMatch[1].length === 4) {
        dobYear = dobMatch[1];
        dobMonth = String(parseInt(dobMatch[2], 10));
        dobDay = String(parseInt(dobMatch[3], 10));
      } else {
        dobDay = String(parseInt(dobMatch[1], 10));
        dobMonth = String(parseInt(dobMatch[2], 10));
        dobYear = dobMatch[3];
      }
    }
  }

  // Parse Full Name into First / Last name fallbacks if not explicitly provided
  let splitFirstName = profileLower["firstname"] || profile["firstName"] || "";
  let splitLastName = profileLower["lastname"] || profile["lastName"] || "";
  const rawFullName = String(profileLower["fullname"] || profile["fullName"] || profileLower["name"] || "").trim();
  if ((!splitFirstName || !splitLastName) && rawFullName) {
    const nameParts = rawFullName.split(/\s+/);
    if (!splitFirstName && nameParts.length > 0) splitFirstName = nameParts[0];
    if (!splitLastName && nameParts.length > 1) splitLastName = nameParts.slice(1).join(" ");
  }

  for (const key of activeFields) {
    if (key === "resume") {
      payload[key] = profileLower["resumedraft"] || profileLower["resume"] || "";
    } else if (key === "phonecode") {
      payload[key] = getPhoneCode(profile);
    } else if (key === "city" || key === "state" || key === "country") {
      payload[key] = getParsedLocationField(profile, key);
    } else if (key === "portalpassword") {
      payload[key] = getPortalPassword(profile);
    } else if (key === "dob_day") {
      payload[key] = dobDay;
    } else if (key === "dob_month") {
      payload[key] = dobMonth;
    } else if (key === "dob_year") {
      payload[key] = dobYear;
    } else if (key === "firstname" && splitFirstName) {
      payload[key] = splitFirstName;
    } else if (key === "lastname" && splitLastName) {
      payload[key] = splitLastName;
    } else if (profileLower[key] !== undefined) {
      payload[key] = profileLower[key];
    } else {
      payload[key] = profile[key] || "";
    }
  }
  return { createdAt: new Date().toISOString(), source: "jobxapply-profile", fields: Array.from(activeFields), payload };
}

function cleanupOrphanedScript() {
  try {
    document.removeEventListener("submit", handleSubmit, true);
    window.removeEventListener("jobxapply:shareAuth", handleShareAuth);
  } catch (e) {}

  document.querySelectorAll(".jxa-knockout-tip, .jxa-mapper-hover, #jxa-mapper-banner, .jxa-mapper-mapped, #jxa-floating-fill-pill").forEach(el => {
    try { el.remove(); } catch(err) {}
  });
}

function checkContext() {
  try {
    if (chrome.runtime && chrome.runtime.id) {
      return true;
    }
  } catch (e) {
    // Context is invalidated
  }
  cleanupOrphanedScript();
  return false;
}

function extractJobMetadata() {
  let title = "";
  let company = "";
  const host = window.location.hostname.toLowerCase();
  const url = window.location.href;

  if (host.includes("greenhouse.io") || host.includes("boards.greenhouse.io")) {
    title = document.querySelector(".app-title, .job-title, h1")?.textContent?.trim() || "";
    company = document.querySelector(".company-name, .logo-wrapper img")?.alt ||
              document.querySelector(".company-name")?.textContent?.trim() || "";
    if (!company) {
      const match = window.location.pathname.match(/\/([^/]+)\/jobs/);
      if (match) company = match[1].charAt(0).toUpperCase() + match[1].slice(1);
    }
  } else if (host.includes("lever.co")) {
    title = document.querySelector(".posting-headline h2, .posting-headline h1")?.textContent?.trim() || "";
    company = document.querySelector(".main-header-logo img")?.alt || "";
    if (!company) {
      const match = window.location.pathname.match(/\/([^/]+)\/[a-f0-9-]+/);
      if (match) company = match[1].charAt(0).toUpperCase() + match[1].slice(1);
    }
  } else if (host.includes("linkedin.com")) {
    title = document.querySelector(".job-details-jobs-unified-top-card__job-title, .top-card-layout__title, h1")?.textContent?.trim() || "";
    company = document.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link, .top-card-layout__first-subline a")?.textContent?.trim() || "";
  } else if (host.includes("myworkdayjobs.com") || host.includes("workday.com")) {
    title = document.querySelector("h2[data-automation-id='jobPostingHeader'], h1")?.textContent?.trim() || "";
    company = document.querySelector("img[data-automation-id='clientLogo']")?.alt || host.split(".")[0];
  } else if (host.includes("indeed.com")) {
    title = document.querySelector(".jobsearch-JobInfoHeader-title, h1")?.textContent?.trim() || "";
    company = document.querySelector("[data-company-name='true'], .jobsearch-InlineCompanyRating-companyHeader")?.textContent?.trim() || "";
  } else if (host.includes("naukri.com")) {
    title = document.querySelector(".jd-header-title, .title, h1")?.textContent?.trim() || "";
    company = document.querySelector(".jd-header-comp-name, .company-name")?.textContent?.trim() || "";
  } else if (host.includes("wellfound.com") || host.includes("angel.co")) {
    title = document.querySelector("h1, .job-title")?.textContent?.trim() || "";
    company = document.querySelector("h2, .company-name")?.textContent?.trim() || "";
  } else if (host.includes("internshala.com")) {
    title = document.querySelector(".heading_4_5.profile, h1")?.textContent?.trim() || "";
    company = document.querySelector(".heading_6.company_name, .company-name")?.textContent?.trim() || "";
  } else if (host.includes("glassdoor.com")) {
    title = document.querySelector("[data-test='jobTitle'], h1")?.textContent?.trim() || "";
    company = document.querySelector("[data-test='employerName']")?.textContent?.trim() || "";
  }

  if (!title) {
    title = document.querySelector("meta[property='og:title']")?.content ||
            document.querySelector("h1")?.textContent?.trim() ||
            document.title.split(/[-|–—:]/)[0].trim();
  }
  if (!company) {
    company = document.querySelector("meta[property='og:site_name']")?.content || "";
    if (!company) {
      const parts = host.replace("www.", "").split(".");
      if (parts.length >= 2) company = parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
    }
  }

  title = title.replace(/\s+/g, " ").trim();
  company = company.replace(/\s+/g, " ").trim();

  return { title: title || "Job Application", company: company || "Company", url, host };
}

const QUESTION_BANK = {
  knockout: [
    "authorized to work", "legally authorized", "visa sponsorship", "require sponsorship", "willing to relocate", "relocate to", "working on-site", "on-site", "willing to work", "shift/weekend", "background check"
  ],
  compensation: [
    "expected salary", "current salary", "salary expectations", "expected ctc", "current ctc", "salary range"
  ],
  logistics: [
    "notice period", "available to start", "earliest start date", "willing to travel", "travel"
  ],
  eeo: [
    "gender", "disability", "disabled", "veteran status", "veteran", "race", "ethnicity", "demographic"
  ],
  essay: [
    "why do you want to work", "why should we hire you", "tell us about yourself", "describe your relevant experience", "looking for in your next role", "walk us through your background"
  ]
};

function identifyQuestionCategory(label) {
  const norm = normalize(label);
  for (const [category, keywords] of Object.entries(QUESTION_BANK)) {
    if (keywords.some(kw => norm.includes(kw))) {
      return category;
    }
  }
  return null;
}

function showKnockoutSuggestion(el, value) {
  const rect = el.getBoundingClientRect();
  const tip = document.createElement("div");
  tip.className = "jxa-knockout-tip";
  tip.style.position = "absolute";
  tip.style.zIndex = "2147483647";
  tip.style.top = `${window.scrollY + rect.top - 32}px`;
  tip.style.left = `${window.scrollX + rect.left}px`;
  tip.style.background = "#fff";
  tip.style.color = "#000";
  tip.style.border = "1px solid #ff9800";
  tip.style.padding = "4px 8px";
  tip.style.borderRadius = "4px";
  tip.style.fontSize = "11px";
  tip.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
  tip.innerHTML = `Suggested: <strong>${value}</strong> <button style="background:#5b4fe8;color:#fff;border:none;padding:2px 6px;margin-left:6px;cursor:pointer;border-radius:2px;">Fill</button>`;
  
  tip.querySelector("button").addEventListener("click", () => {
    setValue(el, value);
    tip.remove();
  });
  document.body.appendChild(tip);
  setTimeout(() => tip.remove(), 8000);
}

// Block auto submits if essay or knockout tips exist
function handleSubmit(e) {
  if (!checkContext()) return;
  if (document.querySelector(".jxa-knockout-tip")) {
    e.preventDefault();
    alert("Please review the knockout question confirmations before submitting.");
  }
}
document.addEventListener("submit", handleSubmit, true);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "jobxapply:getFieldStats") {
    try {
      const inputs = Array.from(document.querySelectorAll("input:not([type='hidden']):not([type='submit']):not([type='button']), textarea, select"));
      const visible = inputs.filter(el => {
        const style = window.getComputedStyle(el);
        return style.display !== "none" && style.visibility !== "hidden" && el.type !== "hidden";
      }).length;
      sendResponse({ ok: true, count: visible });
    } catch (err) {
      sendResponse({ ok: true, count: 0 });
    }
    return true;
  }
  if (message?.type === "jobxapply:autofill") {
    try {
      const rawProfile = message.payload?.payload ? message.payload.payload : (message.payload || {});
      const host = window.location.hostname.toLowerCase();
      const baseDomain = getBaseDomain(host);
      const activeATSMap = getActivePortalMap();
      
      chrome.storage.local.get("portalMaps", (store) => {
        const portalMaps = store.portalMaps || {};
        const portalMap = { ...activeATSMap, ...(portalMaps[baseDomain] || {}) };
        const payload = buildAutofillPayload(rawProfile, Object.keys(rawProfile));
        let filledCount = 0;
        const claimedElements = new Set();

        const PRIORITY_ORDER = [
          "fullname", "firstname", "lastname",
          "email", "phone", "phonecode",
          "currentcompany", "company", "headline", "targetrole",
          "city", "state", "country", "zip", "pincode", "address",
          "linkedin", "github", "portfolio",
          "totalexperience", "experience", "noticeperiod", "expectedsalary",
          "resume", "resumedraft"
        ];

        const entries = Object.entries(payload.payload || {}).sort(([a], [b]) => {
          const idxA = PRIORITY_ORDER.indexOf(a.toLowerCase());
          const idxB = PRIORITY_ORDER.indexOf(b.toLowerCase());
          const rankA = idxA === -1 ? 999 : idxA;
          const rankB = idxB === -1 ? 999 : idxB;
          return rankA - rankB;
        });

        for (const [field, value] of entries) {
          if (!value) continue;
          const mapSelector = portalMap[field] || portalMap[field.toLowerCase()];
          let el = null;
          if (mapSelector) {
            try {
              const matchedEls = Array.from(document.querySelectorAll(mapSelector));
              el = matchedEls.find(e => !claimedElements.has(e)) || null;
            } catch (e) {}
          }
          if (!el) {
            el = findBestElementForKey(field, claimedElements) || findBestElementForKey(field.toLowerCase(), claimedElements) || null;
          }
          if (el && !claimedElements.has(el)) {
            claimedElements.add(el);
            setValue(el, value);
            try {
              const origOutline = el.style.outline;
              el.style.outline = "2px solid #2FDDC4";
              el.style.boxShadow = "0 0 10px rgba(47, 221, 196, 0.4)";
              setTimeout(() => {
                el.style.outline = origOutline;
                el.style.boxShadow = "";
              }, 2500);
            } catch (err) {}
            filledCount++;
          }
        }
        showToastNotification(`JobXApply filled ${filledCount} field${filledCount === 1 ? '' : 's'}!`);
        sendResponse({ ok: true, filledCount });
      });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:insertText") {
    try {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA" || activeEl.contentEditable === "true")) {
        if (activeEl.contentEditable === "true") {
          activeEl.textContent = message.text;
        } else {
          activeEl.value = message.text;
        }
        activeEl.dispatchEvent(new Event("input", { bubbles: true }));
        activeEl.dispatchEvent(new Event("change", { bubbles: true }));
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: "No focused field" });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:getPageText") {
    try {
      const clone = document.body.cloneNode(true);
      const removals = clone.querySelectorAll("script, style, head, iframe, noscript, svg, nav, footer, header");
      removals.forEach(el => el.remove());
      const cleanText = clone.innerText || clone.textContent || "";
      sendResponse({ ok: true, text: cleanText });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:toggleMappingMode") {
    toggleMappingMode();
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "jobxapply:getJobMetadata") {
    try {
      const meta = extractJobMetadata();
      sendResponse({ ok: true, metadata: meta });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:extractJobText") {
    try {
      const clone = document.body.cloneNode(true);
      const removals = clone.querySelectorAll("script, style, head, iframe, noscript, svg, nav, footer, header");
      removals.forEach(el => el.remove());
      const bodyText = (clone.innerText || clone.textContent || "").slice(0, 8000);
      sendResponse({ ok: true, text: bodyText });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:extractJD") {
    try {
      if (typeof extractJD === "function") {
        const jdData = extractJD();
        sendResponse({ ok: true, ...jdData });
      } else {
        const meta = extractJobMetadata();
        const clone = document.body.cloneNode(true);
        const removals = clone.querySelectorAll("script, style, head, iframe, noscript, svg, nav, footer, header");
        removals.forEach(el => el.remove());
        const bodyText = (clone.innerText || clone.textContent || "").slice(0, 8000);
        sendResponse({
          ok: true,
          title: meta.title || "Job Opening",
          company: meta.company || "Company",
          location: "",
          description: bodyText,
          url: window.location.href
        });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:injectResumeFile") {
    try {
      const { fileData, fileName, mimeType } = message;
      if (!fileData) {
        sendResponse({ ok: false, error: "No file data received" });
        return true;
      }
      const binaryStr = atob(fileData);
      const len = binaryStr.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryStr.charCodeAt(i);
      }
      const safeName = fileName || "Resume.pdf";
      const file = new File([bytes], safeName, {
        type: mimeType || "application/pdf",
        lastModified: Date.now()
      });

      const fileInputs = Array.from(document.querySelectorAll('input[type="file"]:not([disabled])'));
      if (fileInputs.length === 0) {
        sendResponse({ ok: false, error: "No file upload input elements found on this page" });
        return true;
      }

      const resumeRegex = /resume|cv|curriculum|vitae|application|document|file/i;
      let targetInput = fileInputs.find(input => {
        const id = input.id || "";
        const name = input.name || "";
        const aria = input.getAttribute("aria-label") || "";
        const accept = input.accept || "";
        const labelText = input.labels ? Array.from(input.labels).map(l => l.innerText).join(" ") : "";
        const containerText = input.closest("label, div, section")?.innerText || "";
        return resumeRegex.test(id) || resumeRegex.test(name) || resumeRegex.test(aria) ||
               resumeRegex.test(accept) || resumeRegex.test(labelText) || resumeRegex.test(containerText.slice(0, 300));
      }) || fileInputs[0];

      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      targetInput.files = dataTransfer.files;

      targetInput.dispatchEvent(new Event("input", { bubbles: true }));
      targetInput.dispatchEvent(new Event("change", { bubbles: true }));

      try {
        const highlightTarget = targetInput.closest("label, div.dropzone, div.upload-container") || targetInput;
        const origOutline = highlightTarget.style.outline;
        const origShadow = highlightTarget.style.boxShadow;
        highlightTarget.style.outline = "2px solid #2FDDC4";
        highlightTarget.style.boxShadow = "0 0 14px rgba(47, 221, 196, 0.5)";
        setTimeout(() => {
          highlightTarget.style.outline = origOutline;
          highlightTarget.style.boxShadow = origShadow;
        }, 3000);
      } catch (err) {}

      showToastNotification("Attached " + safeName + " to form!");
      sendResponse({ ok: true, fileName: safeName, inputId: targetInput.id || targetInput.name || "input[type='file']" });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (message?.type === "jobxapply:receiveProfileFromExtension") {
    if (!isAuthorizedAppOrigin()) {
      sendResponse({ ok: false, error: "Unauthorized origin" });
      return true;
    }
    try {
      window.dispatchEvent(new CustomEvent("jobxapply:populateWebProfile", {
        detail: { profile: message.profile }
      }));
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }

  if (message?.type === "jobxapply:applyAutofill") {
    const profile = message.profile || {};
    const rawProfile = profile.payload ? profile.payload : profile;

    // Guard: if no meaningful data, abort and report to popup
    const hasData = Object.values(rawProfile).some((v) => v && String(v).trim().length > 0);
    if (!hasData) {
      sendResponse({ ok: false, filled: 0, reason: "Profile is empty — set up your profile first" });
      return true;
    }

    const payload = buildAutofillPayload(rawProfile, message.fields || Object.keys(rawProfile));
    const activeATSMap = getActivePortalMap();
    const portalMap = { ...activeATSMap, ...(message.portalMap || {}) };
    const results = [];
    let filledCount = 0;
    const claimedElements = new Set();

    // Prioritize identity and core contact fields first, then career, then screening/education
    const PRIORITY_ORDER = [
      "fullname", "firstname", "lastname",
      "email", "phone", "phonecode",
      "currentcompany", "company", "headline", "targetrole",
      "city", "state", "country", "zip", "pincode", "address",
      "linkedin", "github", "portfolio",
      "totalexperience", "experience", "noticeperiod", "expectedsalary",
      "resume", "resumedraft"
    ];

    const entries = Object.entries(payload.payload || {}).sort(([a], [b]) => {
      const idxA = PRIORITY_ORDER.indexOf(a.toLowerCase());
      const idxB = PRIORITY_ORDER.indexOf(b.toLowerCase());
      const rankA = idxA === -1 ? 999 : idxA;
      const rankB = idxB === -1 ? 999 : idxB;
      return rankA - rankB;
    });

    for (const [field, value] of entries) {
      if (!value) continue;
      const mapSelector = portalMap[field] || portalMap[field.toLowerCase()];
      let el = null;
      if (mapSelector) {
        try {
          const matchedEls = Array.from(document.querySelectorAll(mapSelector));
          el = matchedEls.find(e => !claimedElements.has(e)) || null;
        } catch (e) {}
      }
      if (!el) {
        el = findBestElementForKey(field, claimedElements) || findBestElementForKey(field.toLowerCase(), claimedElements) || null;
      }

      if (el && !claimedElements.has(el)) {
        claimedElements.add(el);
        const labelText = getElementLabelText(el);
        const category = identifyQuestionCategory(labelText);

        if (category === "knockout") {
          showKnockoutSuggestion(el, value);
          results.push({ field, status: "suggested", via: "knockout-rule" });
        } else if (category === "compensation") {
          const expected = rawProfile.expectedSalary || rawProfile.preferences?.expectedSalary || "";
          if (expected) {
            setValue(el, expected);
            filledCount++;
            results.push({ field, status: "filled", via: "compensation-rule" });
          } else {
            el.style.border = "1px solid #eb5757";
            results.push({ field, status: "empty-flagged", via: "compensation-rule" });
          }
        } else if (category === "logistics") {
          const empStatus = rawProfile.employmentStatus || rawProfile.preferences?.employmentStatus || "employed";
          let logisticsVal = value;
          if (empStatus === "student") {
            logisticsVal = "Immediate / Date-based (Graduation)";
          } else if (empStatus === "unemployed") {
            logisticsVal = "Immediate";
          } else {
            const noticeVal = rawProfile.noticePeriod || rawProfile.preferences?.noticePeriod || "";
            if (noticeVal) logisticsVal = noticeVal;
          }
          setValue(el, logisticsVal);
          el.style.backgroundColor = "#ffffe0";
          el.style.border = "1px solid #ffeb3b";
          filledCount++;
          results.push({ field, status: "filled-review", via: "logistics-rule" });
        } else if (category === "eeo") {
          results.push({ field, status: "skipped", via: "eeo-rule" });
        } else if (category === "essay") {
          let chosenAnswer = value;
          if (!chosenAnswer && Array.isArray(rawProfile.customSnippets)) {
            const normLabel = normalize(labelText);
            for (const snip of rawProfile.customSnippets) {
              const aliases = (snip.aliases || "").split(",").map(a => normalize(a)).filter(Boolean);
              if (aliases.some(a => normLabel.includes(a) || a.includes(normLabel))) {
                chosenAnswer = snip.body;
                break;
              }
            }
          }
          if (!chosenAnswer) {
            chosenAnswer = `As a professional with experience in ${rawProfile.skills ? String(rawProfile.skills).split(',').slice(0, 3).join(', ') : 'technology and problem solving'}, I am highly interested in this role. My background aligns directly with your core requirements, and I am excited about the opportunity to contribute to your team.`;
          }
          setValue(el, chosenAnswer);
          el.style.outline = "2px solid #2fddc4";
          filledCount++;
          results.push({ field, status: "filled", via: "vault-essay-rule" });
        } else {
          setValue(el, value);
          try {
            const origOutline = el.style.outline;
            el.style.outline = "2px solid #2FDDC4";
            el.style.boxShadow = "0 0 10px rgba(47, 221, 196, 0.4)";
            setTimeout(() => {
              el.style.outline = origOutline;
              el.style.boxShadow = "";
            }, 2500);
          } catch (err) {}
          filledCount++;
          results.push({ field, status: "filled", via: "heuristic" });
        }
      } else {
        results.push({ field, status: "not-found" });
      }
    }
    sendResponse({ ok: true, filled: filledCount, payload, results });
    return true;
  }
});

function getBaseDomain(hostname) {
  const parts = hostname.replace("www.", "").split(".");
  if (parts.length > 2) {
    const pen = parts[parts.length - 2];
    if (["co", "com", "net", "org", "gov", "edu"].includes(pen) && parts.length > 2) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  return parts.join(".");
}

let mapperStyles = null;
function injectMapperStyles() {
  if (mapperStyles) return;
  mapperStyles = document.createElement("style");
  mapperStyles.textContent = `
    .jxa-mapper-hover {
      outline: 2px solid #5b4fe8 !important;
      outline-offset: 2px !important;
      cursor: crosshair !important;
      box-shadow: 0 0 12px rgba(91, 79, 232, 0.4) !important;
    }
    .jxa-mapper-mapped {
      outline: 2px solid #2fddc4 !important;
      outline-offset: 2px !important;
      background-color: rgba(47, 221, 196, 0.04) !important;
      box-shadow: 0 0 8px rgba(47, 221, 196, 0.2) !important;
    }
  `;
  document.head.appendChild(mapperStyles);
}

function removeMapperStyles() {
  if (mapperStyles) {
    mapperStyles.remove();
    mapperStyles = null;
  }
}

function getUniqueSelector(el) {
  if (el.id) return `#${CSS.escape(el.id)}`;
  if (el.name) return `${el.tagName.toLowerCase()}[name="${CSS.escape(el.name)}"]`;
  
  const path = [];
  let current = el;
  while (current && current.nodeType === Node.ELEMENT_NODE) {
    let selector = current.tagName.toLowerCase();
    if (current.id) {
      selector += `#${CSS.escape(current.id)}`;
      path.unshift(selector);
      break;
    } else {
      let sibIndex = 0;
      let sib = current.previousElementSibling;
      while (sib) {
        if (sib.tagName === current.tagName) sibIndex++;
        sib = sib.previousElementSibling;
      }
      selector += `:nth-of-type(${sibIndex + 1})`;
    }
    path.unshift(selector);
    current = current.parentElement;
  }
  return path.join(" > ");
}

let mapperBanner = null;
let mapperModal = null;
let isMappingActive = false;

function showMapperBanner() {
  if (mapperBanner) return;
  mapperBanner = document.createElement("div");
  mapperBanner.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; height: 48px;
    background: #0b1020; border-bottom: 2px solid #5b4fe8;
    color: #fff; display: flex; align-items: center; justify-content: space-between;
    padding: 0 24px; z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;
    font-size: 13px; box-shadow: 0 4px 20px rgba(0,0,0,0.5);
  `;
  
  const labelDiv = document.createElement("div");
  labelDiv.innerHTML = `<span style="font-weight:700; color:#5b4fe8; margin-right:8px;">JobXApply</span> <span style="color: rgba(255,255,255,0.7)">// Visual Selector Mapper (Click fields to map them)</span>`;
  
  const exitBtn = document.createElement("button");
  exitBtn.textContent = "Exit Mapper";
  exitBtn.style.cssText = `
    background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15);
    border-radius: 8px; color: #fff; padding: 6px 12px; cursor: pointer; font-size: 11px;
    font-weight: 600; font-family: inherit; transition: background 0.2s;
  `;
  exitBtn.addEventListener("mouseover", () => exitBtn.style.background = "rgba(255,255,255,0.15)");
  exitBtn.addEventListener("mouseout", () => exitBtn.style.background = "rgba(255,255,255,0.08)");
  exitBtn.addEventListener("click", () => toggleMappingMode(false));
  
  mapperBanner.appendChild(labelDiv);
  mapperBanner.appendChild(exitBtn);
  document.body.appendChild(mapperBanner);
  document.body.style.paddingTop = "48px";
}

function hideMapperBanner() {
  if (mapperBanner) {
    mapperBanner.remove();
    mapperBanner = null;
    document.body.style.paddingTop = "";
  }
}

const MAPPER_FIELDS = [
  "fullName", "firstName", "lastName", "age", "dob", "email", "phone",
  "address", "city", "state", "country", "zip", "headline", "summary",
  "education", "college", "experience", "skills", "linkedin", "github", "portfolio", "resume", "targetRole"
];

function showMappingModal(el, selector) {
  if (mapperModal) mapperModal.remove();
  
  mapperModal = document.createElement("div");
  mapperModal.style.cssText = `
    position: fixed; inset: 0; background: rgba(5,8,22,0.8);
    display: flex; align-items: center; justify-content: center;
    z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;
    backdrop-filter: blur(8px);
  `;
  
  const container = document.createElement("div");
  container.style.cssText = `
    background: #0b1020; border: 1px solid rgba(255,255,255,0.12);
    border-radius: 16px; padding: 24px; width: 340px; box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    max-height: 80vh; display: flex; flex-direction: column;
  `;
  
  const title = document.createElement("div");
  title.textContent = "Map Input Field";
  title.style.cssText = "font-size: 14px; font-weight:700; color:#fff; margin-bottom: 4px; text-transform:uppercase;";
  
  const preview = document.createElement("div");
  preview.textContent = selector;
  preview.style.cssText = "font-size: 11px; color:rgba(255,255,255,0.5); font-family: monospace; word-break:break-all; margin-bottom: 16px;";
  
  const list = document.createElement("div");
  list.style.cssText = "overflow-y:auto; flex:1; display:flex; flex-direction:column; gap:6px; padding-right:4px;";
  
  MAPPER_FIELDS.forEach(f => {
    const btn = document.createElement("button");
    btn.textContent = f;
    btn.style.cssText = `
      text-align: left; padding: 8px 12px; background: rgba(255,255,255,0.04);
      border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; color: rgba(255,255,255,0.8);
      cursor: pointer; font-size: 12px; transition: background 0.15s, border-color 0.15s;
    `;
    btn.addEventListener("mouseover", () => {
      btn.style.background = "rgba(91,79,232,0.12)";
      btn.style.borderColor = "rgba(91,79,232,0.3)";
    });
    btn.addEventListener("mouseout", () => {
      btn.style.background = "rgba(255,255,255,0.04)";
      btn.style.borderColor = "rgba(255,255,255,0.08)";
    });
    btn.addEventListener("click", () => {
      const domain = getBaseDomain(window.location.hostname);
      chrome.runtime.sendMessage({
        type: "jobxapply:saveCustomMap",
        domain,
        field: f,
        selector
      }, () => {
        el.classList.add("jxa-mapper-mapped");
        showToastNotification(`Mapped field: ${f}`);
        mapperModal.remove();
        mapperModal = null;
      });
    });
    list.appendChild(btn);
  });
  
  const cancelBtn = document.createElement("button");
  cancelBtn.textContent = "Cancel";
  cancelBtn.style.cssText = `
    margin-top: 12px; background: transparent; border: 1px solid rgba(255,255,255,0.15);
    border-radius: 8px; color: #fff; padding: 8px; cursor: pointer; font-size: 12px;
  `;
  cancelBtn.addEventListener("click", () => {
    mapperModal.remove();
    mapperModal = null;
  });
  
  container.appendChild(title);
  container.appendChild(preview);
  container.appendChild(list);
  container.appendChild(cancelBtn);
  mapperModal.appendChild(container);
  document.body.appendChild(mapperModal);
}

function showToastNotification(text) {
  const toast = document.createElement("div");
  toast.textContent = text;
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; background: #070a18;
    border: 1px solid #2fddc4; border-radius: 12px; padding: 12px 20px;
    color: #fff; font-family: sans-serif; font-size: 13px; z-index: 2147483647;
    box-shadow: 0 8px 24px rgba(47, 221, 196, 0.2); transition: opacity 0.3s;
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

function toggleMappingMode(forceState) {
  isMappingActive = typeof forceState === "boolean" ? forceState : !isMappingActive;
  
  if (isMappingActive) {
    injectMapperStyles();
    showMapperBanner();
    highlightExistingMappedFields();
    
    document.addEventListener("mouseover", handleMouseOver, true);
    document.addEventListener("mouseout", handleMouseOut, true);
    document.addEventListener("click", handleFieldClick, true);
    showToastNotification("Visual Mapper Active. Click any field to map.");
  } else {
    hideMapperBanner();
    removeMapperStyles();
    if (mapperModal) {
      mapperModal.remove();
      mapperModal = null;
    }
    
    document.removeEventListener("mouseover", handleMouseOver, true);
    document.removeEventListener("mouseout", handleMouseOut, true);
    document.removeEventListener("click", handleFieldClick, true);
    
    document.querySelectorAll(".jxa-mapper-hover, .jxa-mapper-mapped").forEach(el => {
      el.classList.remove("jxa-mapper-hover", "jxa-mapper-mapped");
    });
  }
}

function handleMouseOver(e) {
  const t = e.target;
  if (t && t.matches && t.matches("input, select, textarea")) {
    e.preventDefault();
    e.stopPropagation();
    t.classList.add("jxa-mapper-hover");
  }
}

function handleMouseOut(e) {
  const t = e.target;
  if (t && t.matches && t.matches("input, select, textarea")) {
    t.classList.remove("jxa-mapper-hover");
  }
}

function handleFieldClick(e) {
  const t = e.target;
  if (t && t.matches && t.matches("input, select, textarea")) {
    e.preventDefault();
    e.stopPropagation();
    t.classList.remove("jxa-mapper-hover");
    
    const selector = getUniqueSelector(t);
    showMappingModal(t, selector);
  }
}


// Validate origin for web-to-extension messages (SEC-01)
function isAuthorizedAppOrigin() {
  try {
    const origin = window.location.origin;
    const href = window.location.href || '';
    if (window.location.protocol === 'file:') {
      if (href.toLowerCase().includes('careerbridge') || href.toLowerCase().includes('jobxapply')) {
        return true;
      }
    }
    if (!origin) return false;
    const lowerOrigin = origin.toLowerCase();
    if (
      lowerOrigin.endsWith(".netlify.app") ||
      lowerOrigin.endsWith(".vercel.app") ||
      lowerOrigin.endsWith(".onrender.com") ||
      lowerOrigin.endsWith(".github.io") ||
      lowerOrigin.includes("jobxapply") ||
      lowerOrigin.includes("careerhub") ||
      lowerOrigin.includes("careerbridge")
    ) {
      return true;
    }
    if (/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
      return true;
    }
    return false;
  } catch (e) {
    return false;
  }
}
const isAuthorizedWebOrigin = isAuthorizedAppOrigin;

// Listen for ping check from extension setup page & dashboard
window.addEventListener("jobxapply:pingExtension", () => {
  if (!isAuthorizedAppOrigin()) return;
  window.dispatchEvent(new CustomEvent("jobxapply:pongExtension", {
    detail: { version: "1.0.0", active: true }
  }));
  try {
    window.postMessage({ type: 'JOBXAPPLY_EXTENSION_PONG', active: true, version: '1.0.0' }, '*');
  } catch(e) {}
});

window.addEventListener("message", (e) => {
  if (e.data && e.data.type === 'JOBXAPPLY_EXTENSION_PING') {
    if (!isAuthorizedAppOrigin()) return;
    try {
      window.postMessage({ type: 'JOBXAPPLY_EXTENSION_PONG', active: true, version: '1.0.0' }, '*');
    } catch(err) {}
    window.dispatchEvent(new CustomEvent("jobxapply:pongExtension", {
      detail: { version: "1.0.0", active: true }
    }));
  }
});

// Listen for pairing event from the JobXApply website
function handleShareAuth(e) {
  if (!checkContext()) return;
  if (!isAuthorizedAppOrigin()) return;
  const { token, passcode, email } = e.detail || {};
  if (token || passcode || email) {
    chrome.runtime.sendMessage({
      type: "jobxapply:saveAuth",
      token: token || "",
      passcode: passcode || "",
      email: email || ""
    }, () => {
      // Catch context error silently if extension got disabled during message send
      if (chrome.runtime.lastError) {}
    });
  }
}
window.addEventListener("jobxapply:shareAuth", handleShareAuth);

// Listen for profile request from web page
window.addEventListener("jobxapply:requestExtensionProfile", () => {
  if (!checkContext()) return;
  if (!isAuthorizedAppOrigin()) return;
  chrome.runtime.sendMessage({ type: "jobxapply:getProfile" }, (res) => {
    if (chrome.runtime.lastError) return;
    const profile = res?.profile || {};
    window.dispatchEvent(new CustomEvent("jobxapply:populateWebProfile", {
      detail: { profile }
    }));
  });
});

// Listen for profile save event from web page to store directly into extension
window.addEventListener("jobxapply:saveWebProfileToExtension", (e) => {
  if (!checkContext()) return;
  if (!isAuthorizedAppOrigin()) return;
  const incoming = e.detail?.profile;
  if (!incoming) return;
  chrome.runtime.sendMessage({
    type: "jobxapply:setProfile",
    profile: incoming
  }, () => {
    if (chrome.runtime.lastError) {}
  });
});

// Floating Quick-Fill Action Pill
function injectFloatingQuickFill() {
  if (!checkContext()) return;
  if (!extensionEnabled) return;
  if (document.getElementById("jxa-floating-fill-pill")) return;
  
  // Honor per-session user dismissal on this origin
  try {
    if (sessionStorage.getItem("jxa_dismiss_pill") === "true") return;
  } catch (e) {}

  if (!isJobPage()) return;

  const candidateInputs = Array.from(document.querySelectorAll("input:not([type='hidden']):not([type='submit']):not([type='button']), textarea, select"));
  const visibleCandidateCount = candidateInputs.filter(el => {
    const style = window.getComputedStyle(el);
    return style.display !== "none" && style.visibility !== "hidden" && el.type !== "hidden";
  }).length;

  if (visibleCandidateCount < 2) return;

  const pill = document.createElement("div");
  pill.id = "jxa-floating-fill-pill";
  pill.style.cssText = `
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 2147483640;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: rgba(7, 10, 24, 0.94);
    color: #ffffff;
    border: 1px solid rgba(91, 79, 232, 0.45);
    border-radius: 9999px;
    padding: 8px 14px 8px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12px;
    font-weight: 600;
    box-shadow: 0 12px 36px rgba(0, 0, 0, 0.65), 0 0 20px rgba(91, 79, 232, 0.25);
    backdrop-filter: blur(16px);
    cursor: pointer;
    user-select: none;
    transition: all 0.22s cubic-bezier(0.16, 1, 0.3, 1);
  `;

  pill.innerHTML = `
    <span style="display:flex;align-items:center;gap:7px;">
      <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#2fddc4;box-shadow:0 0 8px #2fddc4;"></span>
      <strong style="font-weight:800;letter-spacing:-0.01em;">Job<span style="color:#2fddc4;">X</span>Apply</strong>
    </span>
    <span style="width:1px;height:12px;background:rgba(255,255,255,0.15);"></span>
    <span id="jxa-pill-text" style="color:rgba(244,247,255,0.75);font-size:11.5px;">${visibleCandidateCount} fields ready</span>
    <button id="jxa-pill-btn" style="background:linear-gradient(135deg,#5b4fe8,#2fddc4);border:none;border-radius:9999px;color:#fff;font-weight:700;font-size:11px;padding:4px 10px;cursor:pointer;margin-left:2px;box-shadow:0 2px 8px rgba(91,79,232,0.4);">Fill</button>
    <button id="jxa-pill-close" style="background:none;border:none;color:rgba(255,255,255,0.45);font-size:16px;cursor:pointer;padding:0 2px;line-height:1;display:flex;align-items:center;" title="Dismiss">&times;</button>
  `;

  pill.addEventListener("mouseenter", () => {
    pill.style.transform = "translateY(-2px)";
    pill.style.borderColor = "#2fddc4";
    pill.style.boxShadow = "0 16px 40px rgba(0, 0, 0, 0.75), 0 0 24px rgba(47, 221, 196, 0.35)";
  });

  pill.addEventListener("mouseleave", () => {
    pill.style.transform = "translateY(0)";
    pill.style.borderColor = "rgba(91, 79, 232, 0.45)";
    pill.style.boxShadow = "0 12px 36px rgba(0, 0, 0, 0.65), 0 0 20px rgba(91, 79, 232, 0.25)";
  });

  const closeBtn = pill.querySelector("#jxa-pill-close");
  closeBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    try {
      sessionStorage.setItem("jxa_dismiss_pill", "true");
    } catch (err) {}
    pill.remove();
  });

  pill.addEventListener("click", () => {
    const textSpan = pill.querySelector("#jxa-pill-text");
    const fillBtn = pill.querySelector("#jxa-pill-btn");
    pill.style.pointerEvents = "none";
    if (textSpan) textSpan.textContent = "Autofilling...";
    if (fillBtn) fillBtn.style.opacity = "0.5";

    chrome.runtime.sendMessage({ type: "jobxapply:getProfile" }, (res) => {
      if (chrome.runtime.lastError || !res?.profile) {
        if (textSpan) textSpan.textContent = "No profile synced";
        setTimeout(() => { if (pill) pill.remove(); }, 2000);
        return;
      }
      
      const host = window.location.hostname.toLowerCase();
      const baseDomain = getBaseDomain(host);
      const activeATSMap = getActivePortalMap();
      chrome.storage.local.get("portalMaps", (store) => {
        const portalMaps = store.portalMaps || {};
        const portalMap = { ...activeATSMap, ...(portalMaps[baseDomain] || {}) };
        
        chrome.runtime.sendMessage({
          type: "jobxapply:applyAutofill",
          profile: res.profile,
          portalMap
        });

        // Trigger fill directly in content script
        const rawProfile = res.profile.payload ? res.profile.payload : res.profile;
        const payload = buildAutofillPayload(rawProfile, Object.keys(rawProfile));
        let filledCount = 0;
        const claimedElements = new Set();

        const PRIORITY_ORDER = [
          "fullname", "firstname", "lastname",
          "email", "phone", "phonecode",
          "currentcompany", "company", "headline", "targetrole",
          "city", "state", "country", "zip", "pincode", "address",
          "linkedin", "github", "portfolio",
          "totalexperience", "experience", "noticeperiod", "expectedsalary",
          "resume", "resumedraft"
        ];

        const entries = Object.entries(payload.payload || {}).sort(([a], [b]) => {
          const idxA = PRIORITY_ORDER.indexOf(a.toLowerCase());
          const idxB = PRIORITY_ORDER.indexOf(b.toLowerCase());
          const rankA = idxA === -1 ? 999 : idxA;
          const rankB = idxB === -1 ? 999 : idxB;
          return rankA - rankB;
        });

        for (const [field, value] of entries) {
          if (!value) continue;
          const mapSelector = portalMap[field] || portalMap[field.toLowerCase()];
          let el = null;
          if (mapSelector) {
            try {
              const matchedEls = Array.from(document.querySelectorAll(mapSelector));
              el = matchedEls.find(e => !claimedElements.has(e)) || null;
            } catch (e) {}
          }
          if (!el) {
            el = findBestElementForKey(field, claimedElements) || findBestElementForKey(field.toLowerCase(), claimedElements) || null;
          }
          if (el && !claimedElements.has(el)) {
            claimedElements.add(el);
            setValue(el, value);
            try {
              const origOutline = el.style.outline;
              el.style.outline = "2px solid #2FDDC4";
              el.style.boxShadow = "0 0 10px rgba(47, 221, 196, 0.4)";
              setTimeout(() => {
                el.style.outline = origOutline;
                el.style.boxShadow = "";
              }, 2500);
            } catch (err) {}
            filledCount++;
          }
        }

        if (textSpan) textSpan.textContent = `Filled ${filledCount} field${filledCount === 1 ? '' : 's'}!`;
        pill.style.borderColor = "#2fddc4";
        setTimeout(() => {
          if (pill) {
            pill.style.opacity = "0";
            pill.style.transform = "translateY(10px)";
            setTimeout(() => pill.remove(), 400);
          }
        }, 2500);
      });
    });
  });

  document.body.appendChild(pill);
}

// Initialize floating button when DOM is ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    setTimeout(injectFloatingQuickFill, 1200);
  });
} else {
  setTimeout(injectFloatingQuickFill, 1200);
}



