import { getPortalRule, PORTAL_MAPS, generatePasscodeHash, decryptProfileData } from "./shared.js";

const SYNC_API = "http://localhost:8787/api";

async function authenticatedFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["careerhubPasscode"], async (result) => {
      const passcode = result.careerhubPasscode || "";
      const passcodeHash = passcode ? await generatePasscodeHash(passcode) : "";
      
      if (!options.headers) options.headers = {};
      if (passcodeHash) {
        options.headers["Authorization"] = `Bearer ${passcodeHash}`;
      }
      
      try {
        const res = await fetch(url, options);
        resolve(res);
      } catch (e) {
        reject(e);
      }
    });
  });
}

// Fetch maps from backend and cache locally
async function fetchAndCacheMaps() {
  try {
    const res = await fetch(`${SYNC_API}/maps`, { cache: "no-store" });
    if (!res.ok) return;
    const maps = await res.json();
    chrome.storage.local.set({ careerhubMaps: maps });
  } catch (e) {
    // ignore
  }
}

// initial fetch and periodic refresh
fetchAndCacheMaps();
setInterval(fetchAndCacheMaps, 1000 * 60 * 30); // refresh every 30 minutes

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["careerhubProfile"], (result) => {
    if (!result.careerhubProfile) {
      chrome.storage.local.set({
        careerhubProfile: {
          fullName: "",
          firstName: "",
          lastName: "",
          age: 0,
          dob: "",
          fatherName: "",
          motherName: "",
          email: "",
          phone: "",
          address: "",
          city: "",
          state: "",
          country: "",
          zip: "",
          headline: "",
          summary: "",
          education: "",
          college: "",
          experience: "",
          skills: "",
          linkedin: "",
          github: "",
          portfolio: "",
          resumeDraft: "",
          targetRole: ""
        }
      });
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "careerhub:getPortalRule") {
    const rule = getPortalRule(message.url || sender?.url || "");
    sendResponse({ rule });
    return true;
  }
  if (message?.type === "careerhub:getPortalMap") {
    const rule = getPortalRule(message.url || sender?.url || "");
    chrome.storage.local.get(["careerhubMaps"], (result) => {
      const cached = result.careerhubMaps || null;
      let map = null;
      if (cached && cached.maps && cached.maps[rule.portal]) {
        map = cached.maps[rule.portal];
      } else if (cached && cached[rule.portal]) {
        map = cached[rule.portal];
      } else {
        map = PORTAL_MAPS[rule.portal] || null;
      }
      sendResponse({ map });
    });
    return true;
  }
  if (message?.type === "careerhub:getProfile") {
    chrome.storage.local.get(["careerhubState", "careerhubProfile", "careerhubPasscode"], (result) => {
      const passcode = result.careerhubPasscode || "";
      
      const processProfileState = async (state) => {
        let decryptedProfile = state.profile || {};
        if (state.profile && state.profile.encryptedBlob && passcode) {
          try {
            decryptedProfile = await decryptProfileData(state.profile, passcode);
          } catch (e) {
            console.error("Failed to decrypt background profile get:", e);
          }
        }
        return decryptedProfile;
      };

      if (result.careerhubProfile && Object.keys(result.careerhubProfile).length) {
        authenticatedFetch(`${SYNC_API}/profile`)
          .then((res) => res.json())
          .then(async (state) => {
            const profile = await processProfileState(state);
            chrome.storage.local.set({ careerhubState: state, careerhubProfile: profile });
          })
          .catch(() => {});
        sendResponse({ profile: result.careerhubProfile, state: result.careerhubState || null });
        return;
      }

      authenticatedFetch(`${SYNC_API}/profile`)
        .then((res) => res.json())
        .then(async (state) => {
          const profile = await processProfileState(state);
          chrome.storage.local.set({ careerhubState: state, careerhubProfile: profile }, () => {
            sendResponse({ profile, state });
          });
        })
        .catch(() => {
          sendResponse({ profile: {} });
        });
    });
    return true;
  }
  if (message?.type === "careerhub:setProfile") {
    chrome.storage.local.get(["careerhubState", "careerhubPasscode"], (result) => {
      const knownVersion = result.careerhubState?.version || 0;
      const passcode = result.careerhubPasscode || "";
      const payload = { 
        profile: message.profile || {}, 
        passcodeHash: message.passcodeHash || "", 
        origin: "extension", 
        version: knownVersion 
      };
      
      const headers = { "Content-Type": "application/json" };
      if (message.passcodeHash) {
        headers["Authorization"] = `Bearer ${message.passcodeHash}`;
      }
      
      fetch(`${SYNC_API}/profile`, {
        method: "POST",
        headers: headers,
        body: JSON.stringify(payload)
      })
        .then(async (res) => {
          const resultJson = await res.json().catch(() => ({}));
          if (!res.ok) {
            if (res.status === 409 && resultJson?.current) {
              let currentProfile = resultJson.current.profile || {};
              if (resultJson.current.profile && resultJson.current.profile.encryptedBlob && passcode) {
                try {
                  currentProfile = await decryptProfileData(resultJson.current.profile, passcode);
                } catch (e) {
                  console.error("Failed to decrypt conflict profile:", e);
                }
              }
              const decryptedCurrentState = JSON.parse(JSON.stringify(resultJson.current));
              decryptedCurrentState.profile = currentProfile;
              chrome.storage.local.set({ careerhubState: decryptedCurrentState, careerhubProfile: currentProfile }, () => {
                sendResponse({ ok: false, conflict: true, current: decryptedCurrentState });
              });
              return;
            }
            chrome.storage.local.set({ careerhubProfile: message.profile }, () => {
              sendResponse({ ok: false, error: resultJson.error || null, errors: resultJson.errors || null });
            });
            return;
          }
          
          chrome.storage.local.get(["careerhubPasscode"], async (storageResult) => {
            const pc = storageResult.careerhubPasscode || "";
            let decryptedProfile = resultJson.state?.profile || message.profile;
            if (resultJson.state?.profile && resultJson.state.profile.encryptedBlob && pc) {
              try {
                decryptedProfile = await decryptProfileData(resultJson.state.profile, pc);
              } catch (e) {
                console.error("Failed to decrypt response profile:", e);
              }
            }
            const decryptedState = JSON.parse(JSON.stringify(resultJson.state || {}));
            decryptedState.profile = decryptedProfile;
            chrome.storage.local.set({ careerhubState: decryptedState, careerhubProfile: decryptedProfile }, () => {
              sendResponse({ ok: true, state: decryptedState });
            });
          });
        })
        .catch((error) => {
          chrome.storage.local.set({ careerhubProfile: message.profile }, () => {
            sendResponse({ ok: false, error: error.message });
          });
        });
    });
    return true;
  }
  if (message?.type === "careerhub:reportMapIssue") {
    const payload = { report: message.report || {}, origin: "extension" };
    fetch(`${SYNC_API}/report`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload.report || payload)
    })
      .then((res) => res.json())
      .then((result) => {
        sendResponse({ ok: true, result });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err.message });
      });
    return true;
  }
});
