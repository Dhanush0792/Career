import { buildAutofillPayload, getPortalRule, PORTAL_MAPS, generatePasscodeHash, decryptProfileData, encryptProfileData } from "./shared.js";
import { MOCK_PROFILE_DATA } from "./mock-profile-data.js";
import JDMatcher from "./jd-matcher.js";
import CoverLetterEngine from "./cover-letter-engine.js";
import { buildResumePdf, createResumeFile, downloadResumePdf, injectPdfToFileInput } from "./resume-pdf-builder.js";

// ── State ──────────────────────────────────────────────────────────────────
let activeProfile = {};
let allProfiles = {};
let activeProfileId = "default";
let applications = [];
let currentPortalRule = { portal: "unknown", tier: "Tier 3" };
let currentActiveTab = null;
let currentActiveJob = { title: "", company: "", description: "", location: "", url: "" };

// ── Utilities & Toast ──────────────────────────────────────────────────────
function showToast(msg, duration = 2500) {
  const el = document.getElementById("spToast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), duration);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// ── Tab Navigation ─────────────────────────────────────────────────────────
function setupNavigation() {
  const navTabs = document.querySelectorAll(".sp-nav-tab");
  navTabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetView = btn.getAttribute("data-view");
      navTabs.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      document.querySelectorAll(".sp-view").forEach((view) => {
        view.classList.toggle("active", view.id === targetView);
      });

      if (targetView === "dashboardView") updateDashboardUI();
      if (targetView === "trackerView") renderTrackerList();
      if (targetView === "aiResumeCoverView") refreshActiveJobAiView();
    });
  });
}

// ── Live Portal Detection ──────────────────────────────────────────────────
async function updateActivePortalInfo() {
  try {
    currentActiveTab = await getActiveTab();
    const url = currentActiveTab?.url || "";
    currentPortalRule = getPortalRule(url);

    const nameEl = document.getElementById("spPortalName");
    const tierEl = document.getElementById("spPortalTier");
    const dotEl  = document.getElementById("spPortalDot");

    if (nameEl) {
      nameEl.textContent = currentPortalRule.portal !== "unknown" ? currentPortalRule.portal : "Universal Job Form";
    }
    if (tierEl) {
      tierEl.textContent = currentPortalRule.tier || "Active";
    }
    if (dotEl) {
      dotEl.className = currentPortalRule.portal !== "unknown" ? "sp-portal-dot" : "sp-portal-dot unknown";
    }
  } catch (e) {
    console.error("Portal detect error", e);
  }
}

// ── Profile Storage & Management ───────────────────────────────────────────
async function loadStoredProfiles() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["jobxapplyProfiles", "jobxapplyActiveProfileId", "jobxapplyProfile", "jobxapplyPasscode"], (res) => {
      allProfiles = res.jobxapplyProfiles || {};
      activeProfileId = res.jobxapplyActiveProfileId || "default";

      if (allProfiles[activeProfileId]) {
        activeProfile = allProfiles[activeProfileId];
      } else if (res.jobxapplyProfile) {
        activeProfile = res.jobxapplyProfile;
        allProfiles[activeProfileId] = activeProfile;
      } else {
        activeProfile = {};
        allProfiles["default"] = activeProfile;
      }

      const passcodeEl = document.getElementById("setPasscode");
      if (passcodeEl && res.jobxapplyPasscode) {
        passcodeEl.value = res.jobxapplyPasscode;
      }

      populatePersonaDropdown();
      populateProfileForm();
      updateDashboardUI();
      resolve(activeProfile);
    });
  });
}

function populatePersonaDropdown() {
  const sel = document.getElementById("spPersonaSelect");
  if (!sel) return;
  sel.innerHTML = "";
  Object.keys(allProfiles).forEach((id) => {
    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = allProfiles[id].profileName || allProfiles[id].fullName || id;
    if (id === activeProfileId) opt.selected = true;
    sel.appendChild(opt);
  });
}

function populateProfileForm() {
  const p = activeProfile || {};
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val || "";
  };

  setVal("profFullName", p.fullName);
  setVal("profEmail", p.email);
  setVal("profPhone", p.phone);
  setVal("profCity", p.city || (p.address ? `${p.address}, ${p.city || ""}` : ""));
  setVal("profLinkedIn", p.linkedin || p.linkedInUrl);
  setVal("profGitHub", p.github || p.portfolioUrl);
  setVal("profTitle", p.jobTitle || p.headline);
  setVal("profExperienceYears", p.totalExperience || p.yearsOfExperience);
  setVal("profCurrentCompany", p.currentCompany);
  setVal("profNoticePeriod", p.noticePeriodDays || p.noticePeriod);
  setVal("profSummary", p.summary || p.bio);
  setVal("profSkills", Array.isArray(p.skills) ? p.skills.join(", ") : (p.skills || ""));
  setVal("profExpectedSalary", p.expectedFixedSalary || p.expectedSalary);
  setVal("profSalaryCurrency", p.expectedSalaryCurrency || "INR");

  if (p.workAuthStatus) {
    const el = document.getElementById("profAuthWork");
    if (el) el.value = p.workAuthStatus === "Authorized" || p.workAuthStatus === "Yes" ? "Yes" : "No";
  } else if (p.authorizedUs !== undefined) {
    const el = document.getElementById("profAuthWork");
    if (el) el.value = p.authorizedUs ? "Yes" : "No";
  }

  if (p.requireSponsorship !== undefined) {
    const el = document.getElementById("profRequireVisa");
    if (el) el.value = p.requireSponsorship === "Yes" ? "Yes" : "No";
  } else if (p.sponsorshipRequired !== undefined) {
    const el = document.getElementById("profRequireVisa");
    if (el) el.value = p.sponsorshipRequired ? "Yes" : "No";
  }

  if (p.visaType) setVal("profVisaType", p.visaType);
  if (p.willingToRelocate) setVal("profWillingRelocate", p.willingToRelocate);
  if (p.genderIdentity) setVal("profGender", p.genderIdentity);
  if (p.disabilityStatus) setVal("profDisability", p.disabilityStatus);
}

async function saveProfileFromForm() {
  const getVal = (id) => document.getElementById(id)?.value?.trim() || "";

  activeProfile.fullName = getVal("profFullName");
  activeProfile.email = getVal("profEmail");
  activeProfile.phone = getVal("profPhone");
  activeProfile.city = getVal("profCity");
  activeProfile.linkedin = getVal("profLinkedIn");
  activeProfile.linkedInUrl = getVal("profLinkedIn");
  activeProfile.github = getVal("profGitHub");
  activeProfile.portfolioUrl = getVal("profGitHub");
  activeProfile.jobTitle = getVal("profTitle");
  activeProfile.headline = getVal("profTitle");
  activeProfile.totalExperience = getVal("profExperienceYears");
  activeProfile.currentCompany = getVal("profCurrentCompany");
  activeProfile.noticePeriodDays = getVal("profNoticePeriod");
  activeProfile.summary = getVal("profSummary");
  activeProfile.bio = getVal("profSummary");

  const skillsRaw = getVal("profSkills");
  activeProfile.skills = skillsRaw ? skillsRaw.split(",").map((s) => s.trim()).filter(Boolean) : [];

  const isAuth = document.getElementById("profAuthWork")?.value === "Yes";
  const reqSponsor = document.getElementById("profRequireVisa")?.value === "Yes";
  activeProfile.authorizedUs = isAuth;
  activeProfile.workAuthStatus = isAuth ? "Authorized" : "Not Authorized";
  activeProfile.legallyAuthorized = isAuth ? "Yes" : "No";
  activeProfile.sponsorshipRequired = reqSponsor;
  activeProfile.requireSponsorship = reqSponsor ? "Yes" : "No";
  activeProfile.visaType = getVal("profVisaType");
  activeProfile.willingToRelocate = getVal("profWillingRelocate");
  activeProfile.expectedFixedSalary = getVal("profExpectedSalary");
  activeProfile.expectedSalary = getVal("profExpectedSalary");
  activeProfile.expectedSalaryCurrency = getVal("profSalaryCurrency");
  activeProfile.genderIdentity = getVal("profGender");
  activeProfile.disabilityStatus = getVal("profDisability");
  activeProfile.updatedAt = Date.now();

  allProfiles[activeProfileId] = activeProfile;

  await new Promise((resolve) => {
    chrome.storage.local.set({
      jobxapplyProfiles: allProfiles,
      jobxapplyProfile: activeProfile,
      jobxapplyActiveProfileId: activeProfileId
    }, resolve);
  });

  updateDashboardUI();
  showToast("Profile saved & synced to extension!");
}

// ── Dashboard Calculations ─────────────────────────────────────────────────
function calculateCompleteness(p) {
  if (!p) return 0;
  const fields = [
    p.fullName,
    p.email,
    p.phone,
    p.city || p.address,
    p.linkedin || p.linkedInUrl,
    p.jobTitle || p.headline,
    p.summary || p.bio,
    (Array.isArray(p.skills) && p.skills.length > 0) || (typeof p.skills === "string" && p.skills.length > 0)
  ];
  const filled = fields.filter(Boolean).length;
  return Math.round((filled / fields.length) * 100);
}

function updateDashboardUI() {
  const percent = calculateCompleteness(activeProfile);
  const pEl = document.getElementById("dashReadinessPercent");
  const bEl = document.getElementById("dashReadinessBar");
  if (pEl) pEl.textContent = `${percent}%`;
  if (bEl) bEl.style.width = `${percent}%`;

  // Render Snippets
  const snipContainer = document.getElementById("dashSnippetList");
  if (snipContainer) {
    snipContainer.innerHTML = "";
    const items = [
      { label: "Full Name", val: activeProfile.fullName },
      { label: "Email", val: activeProfile.email },
      { label: "Phone", val: activeProfile.phone },
      { label: "LinkedIn", val: activeProfile.linkedin || activeProfile.linkedInUrl },
      { label: "GitHub", val: activeProfile.github || activeProfile.portfolioUrl },
      { label: "Headline", val: activeProfile.jobTitle || activeProfile.headline },
      { label: "Top Skills", val: Array.isArray(activeProfile.skills) ? activeProfile.skills.slice(0, 5).join(", ") : activeProfile.skills }
    ].filter((it) => it.val);

    items.forEach((it) => {
      const row = document.createElement("div");
      row.style.cssText = "display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); padding:6px 10px; border-radius:6px; cursor:pointer;";
      row.title = "Click to copy";
      row.innerHTML = `<span style="font-size:10px; font-weight:700; color:var(--muted);">${it.label}:</span> <span style="font-size:11px; color:#fff; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:200px;">${it.val}</span>`;
      row.addEventListener("click", () => {
        navigator.clipboard.writeText(it.val);
        showToast(`Copied ${it.label}`);
      });
      snipContainer.appendChild(row);
    });
  }

  // Render Recent Applications in Dashboard
  const appContainer = document.getElementById("dashRecentApps");
  if (appContainer) {
    if (!applications || applications.length === 0) {
      appContainer.innerHTML = `<div style="text-align:center; padding:10px; color:var(--dim);">No applications logged yet. Track jobs directly from your browser!</div>`;
    } else {
      appContainer.innerHTML = applications.slice(0, 3).map((app) => `
        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); padding:6px 10px; border-radius:6px; border:1px solid rgba(255,255,255,0.05);">
          <div>
            <span style="font-weight:700; color:#fff;">${app.company || "Unknown"}</span>
            <span style="color:var(--dim);"> &bull; ${app.role || "Role"}</span>
          </div>
          <span style="font-size:9.5px; font-family:var(--mono); padding:2px 6px; border-radius:4px; background:rgba(91,79,232,0.18); color:#a59bf7;">${app.status || "Applied"}</span>
        </div>
      `).join("");
    }
  }
}

// ── Application Tracker ───────────────────────────────────────────────────
function loadTrackerData() {
  chrome.storage.local.get(["jobxapplyApplications"], (res) => {
    applications = res.jobxapplyApplications || [];
    renderTrackerList();
    updateDashboardUI();
  });
}

function renderTrackerList() {
  const container = document.getElementById("trackerList");
  if (!container) return;
  if (!applications || applications.length === 0) {
    container.innerHTML = `<div style="text-align:center; padding:20px; color:var(--dim); font-size:11px;">No applications tracked yet.</div>`;
    return;
  }
  container.innerHTML = applications.map((app, idx) => `
    <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.08); border-radius:8px; padding:8px 12px;">
      <div>
        <div style="font-size:12px; font-weight:700; color:#fff;">${app.company || "Company"}</div>
        <div style="font-size:10.5px; color:var(--muted);">${app.role || "Role"} &bull; <span style="font-size:9px; color:var(--dim);">${new Date(app.appliedAt || Date.now()).toLocaleDateString()}</span></div>
      </div>
      <div style="display:flex; align-items:center; gap:8px;">
        <span style="font-size:10px; font-family:var(--mono); padding:3px 7px; border-radius:4px; background:rgba(47,221,196,0.12); color:#2FDDC4; font-weight:700;">${app.status}</span>
        <button data-del="${idx}" style="background:none; border:none; color:var(--danger); cursor:pointer; font-size:13px;" title="Delete">&times;</button>
      </div>
    </div>
  `).join("");

  container.querySelectorAll("[data-del]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.getAttribute("data-del"), 10);
      applications.splice(idx, 1);
      chrome.storage.local.set({ jobxapplyApplications: applications }, () => {
        renderTrackerList();
        updateDashboardUI();
        showToast("Application removed");
      });
    });
  });
}

async function trackCurrentJobFromActiveTab() {
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.id) {
      showToast("No active browser tab found.");
      return;
    }
    
    showToast("Extracting job details from tab...");
    chrome.tabs.sendMessage(tab.id, { type: "jobxapply:getJobMetadata" }, (res) => {
      let meta = res?.metadata;
      if (!meta || !meta.title) {
        const titleParts = (tab.title || "").split(/[-|–—:]/);
        meta = {
          title: titleParts[0]?.trim() || "Software Engineer",
          company: titleParts[1]?.trim() || "Company",
          url: tab.url || "",
          host: new URL(tab.url || "https://example.com").hostname
        };
      }

      const p = activeProfile || {};
      const newApp = {
        id: "app_" + Date.now().toString(36),
        company: meta.company || "Target Company",
        role: meta.title || "Target Role",
        portal: meta.host ? meta.host.replace("www.", "") : "Online Portal",
        status: "Applied",
        date: new Date().toISOString().split("T")[0],
        appliedAt: Date.now(),
        salary: p.expectedFixedSalary ? `${p.expectedSalaryCurrency || 'INR'} ${p.expectedFixedSalary}` : "Market Standard",
        location: p.city || "Remote",
        url: meta.url || tab.url || "",
        notes: `Captured in 1-click from ${meta.portal || meta.host || "active page"}.`
      };

      const exists = applications.find(a => (a.url && a.url === newApp.url) || (a.company.toLowerCase() === newApp.company.toLowerCase() && a.role.toLowerCase() === newApp.role.toLowerCase()));
      if (exists) {
        showToast(`Already tracked: ${newApp.role} @ ${newApp.company}`);
        return;
      }

      applications.unshift(newApp);
      chrome.storage.local.set({ jobxapplyApplications: applications }, () => {
        renderTrackerList();
        updateDashboardUI();
        showToast(`Tracked: ${newApp.role} @ ${newApp.company}!`, 3000);
      });
    });
  } catch (err) {
    console.error("Track error", err);
    showToast("Could not track current tab.");
  }
}

function saveNewApplication() {
  const company = document.getElementById("trCompany")?.value?.trim();
  const role = document.getElementById("trRole")?.value?.trim();
  const status = document.getElementById("trStatus")?.value || "Applied";
  const url = document.getElementById("trUrl")?.value?.trim() || currentActiveTab?.url || "";

  if (!company) {
    showToast("Please enter a company name");
    return;
  }

  const app = {
    id: "app_" + Date.now().toString(36),
    company,
    role: role || "Candidate",
    status,
    url,
    appliedAt: Date.now()
  };

  applications.unshift(app);
  chrome.storage.local.set({ jobxapplyApplications: applications }, () => {
    document.getElementById("trCompany").value = "";
    document.getElementById("trRole").value = "";
    document.getElementById("trUrl").value = "";
    renderTrackerList();
    updateDashboardUI();
    showToast(`Tracked application for ${company}!`);
  });
}

// ── Autofill Execution ─────────────────────────────────────────────────────
async function executeAutofill() {
  try {
    const tab = await getActiveTab();
    if (!tab?.id) {
      showToast("No active browser tab found");
      return;
    }

    const payload = buildAutofillPayload(activeProfile, currentPortalRule);

    chrome.tabs.sendMessage(tab.id, {
      type: "jobxapply:autofill",
      payload: payload,
      portal: currentPortalRule.portal
    }, (res) => {
      if (chrome.runtime.lastError) {
        showToast("Cannot autofill this page: " + chrome.runtime.lastError.message);
      } else {
        showToast(`Filled fields on ${currentPortalRule.portal || "portal"}!`);
      }
    });
  } catch (e) {
    showToast("Autofill failed: " + e.message);
  }
}

// ── Resume Generator ───────────────────────────────────────────────────────
function compileResume() {
  const p = activeProfile || {};
  const skillsText = Array.isArray(p.skills) ? p.skills.join(" • ") : (p.skills || "Not specified");

  const resumeText = `${(p.fullName || "YOUR NAME").toUpperCase()}
${p.email || "email@example.com"} | ${p.phone || "+1 555-0199"} | ${p.city || "San Francisco, CA"}
${p.linkedin || ""} ${p.github ? "| " + p.github : ""}

PROFESSIONAL SUMMARY
${p.summary || "Results-driven professional with expertise delivering scalable impact and building robust solutions."}

SKILLS & CORE COMPETENCIES
${skillsText}

PROFESSIONAL EXPERIENCE
${p.currentCompany || "Leading Enterprise"} — ${p.jobTitle || "Software Engineer"}
• Engineered high-performance architectures improving reliability across critical user flows.
• Streamlined automated workflows reducing manual form processing time.
• Collaborated with cross-functional engineering and product stakeholders.

EDUCATION
Bachelor of Science in Computer Science / Related Field
`;

  const container = document.getElementById("resumePreviewContainer");
  if (container) {
    container.textContent = resumeText;
  }
  showToast("Resume compiled successfully!");
}

// ── ATS Checker ────────────────────────────────────────────────────────────
function runAtsAnalysis() {
  const jdText = document.getElementById("atsJdInput")?.value?.trim() || "";
  if (!jdText) {
    showToast("Please paste or extract a job description first");
    return;
  }

  const jdWords = jdText.toLowerCase().match(/\b[a-z]{3,}\b/g) || [];
  const commonStopWords = new Set(["and", "the", "for", "with", "that", "this", "from", "have", "will", "your", "work", "team", "years", "role"]);
  const jdKeywords = [...new Set(jdWords.filter((w) => !commonStopWords.has(w)))];

  const profileText = JSON.stringify(activeProfile).toLowerCase();

  const matched = [];
  const missing = [];

  jdKeywords.slice(0, 30).forEach((kw) => {
    if (profileText.includes(kw)) {
      matched.push(kw);
    } else {
      missing.push(kw);
    }
  });

  const total = matched.length + missing.length;
  const score = total > 0 ? Math.round((matched.length / total) * 100) : 70;

  const resultsCard = document.getElementById("atsResultsCard");
  const scoreVal = document.getElementById("atsScoreValue");
  const scoreBar = document.getElementById("atsScoreBar");
  const matchedEl = document.getElementById("atsMatchedList");
  const missingEl = document.getElementById("atsMissingList");
  const suggEl = document.getElementById("atsSuggestionsList");

  if (resultsCard) resultsCard.style.display = "block";
  if (scoreVal) scoreVal.textContent = `${score}%`;
  if (scoreBar) scoreBar.style.width = `${score}%`;

  if (matchedEl) {
    matchedEl.innerHTML = matched.slice(0, 15).map((m) => `
      <span style="font-size:9.5px; font-family:var(--mono); padding:2px 6px; border-radius:4px; background:rgba(47,221,196,0.15); color:#2FDDC4;">+ ${m}</span>
    `).join("");
  }

  if (missingEl) {
    missingEl.innerHTML = missing.slice(0, 15).map((m) => `
      <span style="font-size:9.5px; font-family:var(--mono); padding:2px 6px; border-radius:4px; background:rgba(245,166,35,0.15); color:#ffc254;">- ${m}</span>
    `).join("");
  }

  if (suggEl) {
    suggEl.innerHTML = `
      <li>Incorporate missing keywords (${missing.slice(0, 4).join(", ")}) into your experience bullet points.</li>
      <li>Keep single-column typography to maximize machine parseability.</li>
      <li>Ensure job title matches the target title directly in your resume header.</li>
    `;
  }

  showToast(`ATS Score calculated: ${score}%`);
}

async function extractJdFromActiveTab() {
  try {
    const tab = await getActiveTab();
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { type: "jobxapply:extractJobText" }, (res) => {
      if (res?.text) {
        document.getElementById("atsJdInput").value = res.text.slice(0, 4000);
        showToast("Extracted job description from page!");
      } else {
        showToast("Paste job description manually or ensure job tab is focused");
      }
    });
  } catch (e) {
    showToast("Could not extract from tab");
  }
}

// ── Cover Letter Generator ─────────────────────────────────────────────────
function generateCoverLetter() {
  const p = activeProfile || {};
  const company = document.getElementById("clCompanyInput")?.value?.trim() || "Hiring Team";
  const role = document.getElementById("clRoleInput")?.value?.trim() || (p.jobTitle || "Software Engineer");
  const strengths = document.getElementById("clKeyStrengths")?.value?.trim() || (Array.isArray(p.skills) ? p.skills.slice(0, 3).join(", ") : "software architecture and problem solving");

  const letter = `Dear ${company} Hiring Team,

I am writing to express my strong enthusiasm for the ${role} position at ${company}. With a track record of driving scalable results and deep expertise in ${strengths}, I am confident in my ability to make an immediate, meaningful impact on your team.

Throughout my career, I have focused on delivering high-reliability systems and optimizing performance across complex product flows. At ${p.currentCompany || "my current organization"}, I championed initiatives that improved efficiency and solved mission-critical bottlenecks.

What excites me most about ${company} is your commitment to high engineering standards and user-centric innovation. I look forward to bringing my background in ${strengths} to help accelerate your upcoming milestones.

Thank you for your time and consideration. I welcome the opportunity to discuss how my qualifications align with your goals.

Sincerely,
${p.fullName || "Candidate"}
${p.email || ""} | ${p.phone || ""}
${p.linkedin || ""}`;

  const out = document.getElementById("clOutput");
  if (out) out.value = letter;
  showToast("Drafted cover letter!");
}

// ── Event Listeners ────────────────────────────────────────────────────────

// ── AI Resume & Cover Letter Functions ─────────────────────────────────────
async function refreshActiveJobAiView() {
  const titleEl = document.getElementById("spAiJobTitle");
  const compEl = document.getElementById("spAiJobCompany");
  const badgeEl = document.getElementById("spAiAtsBadge");
  const barEl = document.getElementById("spAiScoreBar");
  const pillsEl = document.getElementById("spAiKeywordPills");

  try {
    const tab = await getActiveTab();
    if (!tab?.id) {
      if (titleEl) titleEl.textContent = "No active tab detected";
      return;
    }

    if (titleEl) titleEl.textContent = "Extracting job details from tab...";
    chrome.tabs.sendMessage(tab.id, { type: "jobxapply:extractJD" }, (res) => {
      if (chrome.runtime.lastError || !res || !res.ok) {
        // Fallback to tab metadata
        const titleParts = (tab.title || "").split(/[-|–—:]/);
        currentActiveJob = {
          title: titleParts[0]?.trim() || "Target Role",
          company: titleParts[1]?.trim() || currentPortalRule.portal !== "unknown" ? currentPortalRule.portal : "Company",
          description: tab.title || "",
          location: "",
          url: tab.url || ""
        };
      } else {
        currentActiveJob = {
          title: res.title || "Target Role",
          company: res.company || "Company",
          description: res.description || "",
          location: res.location || "",
          url: res.url || tab.url || ""
        };
      }

      if (titleEl) titleEl.textContent = currentActiveJob.title;
      if (compEl) compEl.textContent = currentActiveJob.company + (currentActiveJob.location ? " • " + currentActiveJob.location : "");

      // Also pre-fill the manual ATS and Cover Letter tabs
      const atsJd = document.getElementById("atsJdInput");
      if (atsJd && currentActiveJob.description && !atsJd.value) {
        atsJd.value = currentActiveJob.description.slice(0, 4000);
      }
      const clComp = document.getElementById("clCompanyInput");
      if (clComp && currentActiveJob.company) clComp.value = currentActiveJob.company;
      const clRole = document.getElementById("clRoleInput");
      if (clRole && currentActiveJob.title) clRole.value = currentActiveJob.title;

      // Run ATS Matcher using local JDMatcher module
      const jdText = currentActiveJob.description || (currentActiveJob.title + " " + currentActiveJob.company);
      const matchResult = JDMatcher.matchJD(jdText, activeProfile);
      const atsScore = matchResult.score || 75;

      if (badgeEl) {
        badgeEl.textContent = `ATS ${atsScore}%`;
        badgeEl.style.borderColor = atsScore >= 75 ? "#2fddc4" : (atsScore >= 50 ? "#f5a623" : "#ff5c5c");
        badgeEl.style.color = atsScore >= 75 ? "#2fddc4" : (atsScore >= 50 ? "#f5a623" : "#ff5c5c");
      }
      if (barEl) {
        barEl.style.width = `${atsScore}%`;
      }

      if (pillsEl) {
        pillsEl.innerHTML = "";
        const matchedPills = (matchResult.matched || []).slice(0, 5).map(kw => 
          `<span style="background:rgba(47,221,196,0.15); color:#2fddc4; padding:2px 6px; border-radius:4px; font-weight:600;">✓ ${kw}</span>`
        ).join("");
        const missingPills = (matchResult.missing || []).slice(0, 4).map(kw =>
          `<span style="background:rgba(245,166,35,0.15); color:#f5a623; padding:2px 6px; border-radius:4px; font-weight:600;">+ ${kw}</span>`
        ).join("");
        pillsEl.innerHTML = (matchedPills || missingPills) ? (matchedPills + missingPills) : '<span style="color:var(--muted);">Keyword extraction complete.</span>';
      }
    });
  } catch (err) {
    console.error("refreshActiveJobAiView error:", err);
  }
}

function getTailoredProfileForActiveJob() {
  const p = { ...activeProfile };
  // Extract keywords from active job description
  const jdText = currentActiveJob.description || (currentActiveJob.title + " " + currentActiveJob.company);
  const extracted = JDMatcher.extractKeywordsFromJD(jdText);
  const highPriority = (extracted?.highPriority || []).slice(0, 5);

  // Blend top job keywords into skills if not already present
  let existingSkills = Array.isArray(p.skills) ? [...p.skills] : (typeof p.skills === "string" ? p.skills.split(",").map(s => s.trim()) : []);
  const lowerExisting = new Set(existingSkills.map(s => s.toLowerCase()));
  highPriority.forEach(hp => {
    if (!lowerExisting.has(hp.toLowerCase())) {
      existingSkills.push(hp);
    }
  });
  p.skills = existingSkills;

  if (currentActiveJob.title && currentActiveJob.title !== "Target Role") {
    p.targetRole = currentActiveJob.title;
  }
  return p;
}

function handleDownloadTailoredResume() {
  const tailored = getTailoredProfileForActiveJob();
  const safeName = (tailored.fullName || tailored.name || "Resume").replace(/[^a-zA-Z0-9_-]/g, "_");
  const jobSuffix = (currentActiveJob.company || "Job").replace(/[^a-zA-Z0-9_-]/g, "_");
  const filename = `${safeName}_${jobSuffix}_Resume.pdf`;

  downloadResumePdf(tailored, filename);
  showToast("Downloading tailored ATS resume PDF!");
}

async function handleAutoAttachResumeToForm() {
  const statusEl = document.getElementById("spAiAttachStatus");
  if (statusEl) statusEl.textContent = "Generating tailored PDF & attaching to portal...";

  try {
    const tab = await getActiveTab();
    if (!tab?.id) {
      if (statusEl) statusEl.textContent = "No active tab found.";
      showToast("No active browser tab found");
      return;
    }

    const tailored = getTailoredProfileForActiveJob();
    const safeName = (tailored.fullName || tailored.name || "Resume").replace(/[^a-zA-Z0-9_-]/g, "_");
    const jobSuffix = (currentActiveJob.company || "Job").replace(/[^a-zA-Z0-9_-]/g, "_");
    const filename = `${safeName}_${jobSuffix}_Resume.pdf`;

    // Build raw PDF Uint8Array buffer
    const pdfBytes = buildResumePdf(tailored);

    // Convert Uint8Array to base64 binary string
    let binary = "";
    const len = pdfBytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(pdfBytes[i]);
    }
    const fileDataBase64 = btoa(binary);

    chrome.tabs.sendMessage(tab.id, {
      type: "jobxapply:injectResumeFile",
      fileData: fileDataBase64,
      fileName: filename,
      mimeType: "application/pdf"
    }, (res) => {
      if (chrome.runtime.lastError) {
        if (statusEl) statusEl.textContent = "Error: " + chrome.runtime.lastError.message;
        showToast("Content script error");
        return;
      }
      if (res?.ok) {
        if (statusEl) statusEl.textContent = `✓ Attached ${filename} to ${res.inputId}!`;
        showToast(`Attached tailored resume to application form!`);
      } else {
        if (statusEl) statusEl.textContent = res?.error || "Could not find file input on page";
        showToast(res?.error || "File input not found");
      }
    });
  } catch (err) {
    if (statusEl) statusEl.textContent = "Attach error: " + err.message;
    console.error("handleAutoAttachResumeToForm error:", err);
  }
}

function handleGenerateAiCoverLetter() {
  const template = document.getElementById("spAiCoverTemplateSelect")?.value || "technical";
  const outputEl = document.getElementById("spAiCoverOutput");

  const tailored = getTailoredProfileForActiveJob();
  const jdText = currentActiveJob.description || (currentActiveJob.title + " " + currentActiveJob.company);

  const letterText = CoverLetterEngine.generateCoverLetter(tailored, {
    companyName: currentActiveJob.company || "Hiring Team",
    jobTitle: currentActiveJob.title || "Software Engineer",
    template: template,
    jdText: jdText
  });

  if (outputEl) outputEl.value = letterText;
  showToast("Generated ATS cover letter!");
}

function handleCopyAiCoverLetter() {
  const outputEl = document.getElementById("spAiCoverOutput");
  const text = outputEl?.value || "";
  if (!text) {
    showToast("Generate a cover letter first");
    return;
  }
  navigator.clipboard.writeText(text);
  showToast("Copied cover letter to clipboard!");
}

function handleDownloadAiCoverLetter() {
  const outputEl = document.getElementById("spAiCoverOutput");
  const text = outputEl?.value || "";
  if (!text) {
    showToast("Generate a cover letter first");
    return;
  }
  const comp = (currentActiveJob.company || "Company").replace(/[^a-zA-Z0-9_-]/g, "_");
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Cover_Letter_${comp}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  showToast("Cover letter downloaded!");
}

document.addEventListener("DOMContentLoaded", async () => {
  setupNavigation();
  await updateActivePortalInfo();
  await loadStoredProfiles();
  loadTrackerData();

  // Header & Global Actions
  document.getElementById("spAutofillActiveBtn")?.addEventListener("click", executeAutofill);
  document.getElementById("dashFillBtn")?.addEventListener("click", executeAutofill);
  document.getElementById("spOpenFullTabBtn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("sidepanel.html") });
  });

  // Persona Switching
  document.getElementById("spPersonaSelect")?.addEventListener("change", (e) => {
    activeProfileId = e.target.value;
    activeProfile = allProfiles[activeProfileId] || activeProfile;
    chrome.storage.local.set({ jobxapplyActiveProfileId: activeProfileId }, () => {
      populateProfileForm();
      updateDashboardUI();
      showToast(`Switched persona to ${e.target.value}`);
    });
  });

  // Profile Form Saving
  document.getElementById("saveProfileBtn")?.addEventListener("click", saveProfileFromForm);
  document.getElementById("saveProfileBottomBtn")?.addEventListener("click", saveProfileFromForm);

  // Resume Actions
  document.getElementById("generateResumeBtn")?.addEventListener("click", compileResume);
  document.getElementById("copyResumeTextBtn")?.addEventListener("click", () => {
    const text = document.getElementById("resumePreviewContainer")?.textContent || "";
    navigator.clipboard.writeText(text);
    showToast("Copied resume text!");
  });

  // AI Resume & Cover Letter Tab Actions
  document.getElementById("spAiRefreshJobBtn")?.addEventListener("click", refreshActiveJobAiView);
  document.getElementById("spAiDownloadResumeBtn")?.addEventListener("click", handleDownloadTailoredResume);
  document.getElementById("spAiAttachResumeBtn")?.addEventListener("click", handleAutoAttachResumeToForm);
  document.getElementById("spAiGenCoverBtn")?.addEventListener("click", handleGenerateAiCoverLetter);
  document.getElementById("spAiCopyCoverBtn")?.addEventListener("click", handleCopyAiCoverLetter);
  document.getElementById("spAiDownloadCoverBtn")?.addEventListener("click", handleDownloadAiCoverLetter);

  // ATS Checker Actions
  document.getElementById("atsRunCheckBtn")?.addEventListener("click", runAtsAnalysis);
  document.getElementById("atsExtractFromTabBtn")?.addEventListener("click", extractJdFromActiveTab);

  // Cover Letter Actions
  document.getElementById("clGenerateBtn")?.addEventListener("click", generateCoverLetter);
  document.getElementById("clCopyBtn")?.addEventListener("click", () => {
    const text = document.getElementById("clOutput")?.value || "";
    navigator.clipboard.writeText(text);
    showToast("Copied cover letter!");
  });

  // Tracker Actions
  document.getElementById("spTrackJobBannerBtn")?.addEventListener("click", trackCurrentJobFromActiveTab);
  document.getElementById("dashLogAppBtn")?.addEventListener("click", trackCurrentJobFromActiveTab);
  document.getElementById("trSaveBtn")?.addEventListener("click", saveNewApplication);

  // Settings Actions
  document.getElementById("setSavePasscodeBtn")?.addEventListener("click", () => {
    const passcode = document.getElementById("setPasscode")?.value?.trim() || "";
    chrome.storage.local.set({ jobxapplyPasscode: passcode }, () => {
      showToast("Vault Passcode updated!");
    });
  });

  document.getElementById("setLoadMockBtn")?.addEventListener("click", () => {
    activeProfile = { ...MOCK_PROFILE_DATA };
    allProfiles[activeProfileId] = activeProfile;
    chrome.storage.local.set({
      jobxapplyProfiles: allProfiles,
      jobxapplyProfile: activeProfile
    }, () => {
      populateProfileForm();
      updateDashboardUI();
      showToast("Loaded sample test profile!");
    });
  });

  document.getElementById("setNewPersonaBtn")?.addEventListener("click", () => {
    const name = prompt("Enter persona name (e.g. SDE, Product Manager):");
    if (!name) return;
    const newId = "persona_" + Date.now().toString(36);
    allProfiles[newId] = {
      ...activeProfile,
      profileName: name,
      jobTitle: name
    };
    activeProfileId = newId;
    activeProfile = allProfiles[newId];
    chrome.storage.local.set({
      jobxapplyProfiles: allProfiles,
      jobxapplyProfile: activeProfile,
      jobxapplyActiveProfileId: activeProfileId
    }, () => {
      populatePersonaDropdown();
      populateProfileForm();
      updateDashboardUI();
      showToast(`Created persona: ${name}`);
    });
  });

  // Listen to tab events to update detected portal live in the side panel
  if (chrome.tabs && chrome.tabs.onActivated) {
    chrome.tabs.onActivated.addListener(updateActivePortalInfo);
  }
  if (chrome.tabs && chrome.tabs.onUpdated) {
    chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
      if (changeInfo.status === "complete") {
        updateActivePortalInfo();
      }
    });
  }
});
