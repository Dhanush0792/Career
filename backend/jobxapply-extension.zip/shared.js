export const DEFAULT_PROFILE_FIELDS = [
  "fullName", "firstName", "middleName", "lastName", "age", "dob", "dob_day", "dob_month", "dob_year", "gender", "fatherName", "motherName",
  "email", "phoneCode", "phone", "address", "city", "state", "country", "zip", "headline",
  "summary", "education", "college", "experience", "skills", "linkedin", "github",
  "portfolio", "resumeDraft", "targetRole", "portalPassword", "answers",
  "leetcode", "availability", "noticePeriod", "totalExperience",
  "alternativeEmail", "pincode", "maritalStatus", "employmentStatus",
  "expectedSalary", "currentSalary", "handicapped", "healthIssues", "targetRoles",
  "coverLetterDraft", "otherDocuments",
  "q_why_hire", "q_why_company", "q_achievement", "q_challenge", "q_strengths_weaknesses", "q_leadership",
  "edu10_school", "edu10_board", "edu10_year", "edu10_cgpa",
  "edu12_school", "edu12_board", "edu12_year", "edu12_cgpa",
  "eduGrad_college", "eduGrad_degree", "eduGrad_stream", "eduGrad_year", "eduGrad_cgpa", "eduGrad_pursuing",
  "eduPG_college", "eduPG_degree", "eduPG_stream", "eduPG_year", "eduPG_cgpa", "eduPG_pursuing",
  "eduMasters_college", "eduMasters_degree", "eduMasters_stream", "eduMasters_year", "eduMasters_cgpa", "eduMasters_pursuing",
  "eduPhD_college", "eduPhD_degree", "eduPhD_stream", "eduPhD_year", "eduPhD_cgpa", "eduPhD_pursuing",
  "workAuthStatus", "requireSponsorship", "visaType", "noticePeriodDays", "willingToRelocate", "willingToTravel",
  "earliestStartDate", "currentFixedSalary", "currentSalaryCurrency", "expectedFixedSalary", "expectedSalaryCurrency",
  "salaryNegotiable", "genderIdentity", "veteranStatus", "disabilityStatus", "raceEthnicity", "legallyAuthorized",
  "previouslyEmployedHere", "hasRelativesHere", "securityClearance",
  "experienceList", "projectsList", "certificationsList"
];

export const FIELD_ALIASES = {
  fullName: ["fullname", "full name", "applicant name", "candidate name", "candidate's name", "your name", "full_name", "applicant_name", "cand_name", "complete name", "name"],
  firstName: ["first", "firstname", "given name", "first name", "fname", "first_name", "forename"],
  middleName: ["middle", "middlename", "middle name", "mname", "middle_name"],
  lastName: ["last", "lastname", "surname", "family name", "last name", "lname", "last_name"],
  age: ["age", "current age", "age in years", "applicant age"],
  dob: ["dob", "date of birth", "birthdate", "birthday", "birth date", "d.o.b", "d.o.b.", "date_of_birth"],
  dob_day: ["birth day", "dob day", "day of birth", "day (dob)", "birthdate day", "dd", "dob_dd", "dob_day"],
  dob_month: ["birth month", "dob month", "month of birth", "month (dob)", "birthdate month", "mm", "dob_mm", "dob_month"],
  dob_year: ["birth year", "dob year", "year of birth", "year (dob)", "birthdate year", "yyyy", "dob_yyyy", "dob_year"],
  gender: ["gender", "sex"],
  fatherName: ["father's name", "father name", "guardian name", "father", "parent name", "fathers name", "father_name"],
  motherName: ["mother's name", "mother name", "mother", "mothers name", "mother_name"],
  email: ["email", "email address", "e-mail", "e-mail address", "user email", "primary email", "email_address", "cand_email", "applicant email"],
  phone: ["phone", "phone number", "mobile", "mobile number", "telephone", "cell", "cell phone", "contact number", "primary phone", "cand_phone", "applicant phone", "contact no", "mobile no"],
  phoneCode: ["phone code", "country code", "country/region code", "dial code", "calling code", "phone prefix", "isd code", "dialling code", "std code"],
  address: ["address", "street", "address1", "address line 1", "residential address", "permanent address", "current address", "street address", "line 1"],
  city: ["city", "town", "district", "current city"],
  state: ["state", "province", "region", "state/province", "state / province"],
  country: ["country", "nation", "citizenship country", "country/region"],
  zip: ["zip", "postal", "postal code", "zipcode", "zip code", "pin", "pincode", "pin code", "area code"],
  headline: ["headline", "professional headline", "title", "job title", "profile title"],
  summary: ["summary", "about", "about me", "bio", "description", "profile summary", "personal summary", "executive summary", "career objective", "objective"],
  education: ["education", "qualifications", "degree", "highest qualification", "academic background"],
  college: ["college", "university", "institution", "institute name", "school/university", "college/university"],
  experience: ["experience", "work experience", "employment", "professional experience", "past experience"],
  skills: ["skills", "skillset", "key skills", "technical skills", "core skills", "competencies"],
  linkedin: ["linkedin", "linked in", "linkedin profile", "linkedin url", "linkedin link"],
  github: ["github", "git hub", "github url", "github profile", "github link"],
  portfolio: ["portfolio", "website", "site", "personal website", "portfolio url", "portfolio link", "web site"],
  resumeDraft: ["resume", "cv", "curriculum vitae", "upload resume", "attach resume", "upload cv"],
  targetRole: ["role", "target role", "position", "designation", "desired role", "applied position", "job profile", "applying for"],
  portalPassword: ["choose password", "password", "create password", "new password", "portal password", "account password"],
  alternativeEmail: ["alternative email", "alt email", "alternate email", "secondary email", "alt_email"],
  pincode: ["pincode", "pin code", "postal code", "zip", "zip code", "area pincode"],
  maritalStatus: ["marital status", "marital", "marriage status", "single/married", "marital_status"],
  employmentStatus: ["employment status", "employment", "job status", "current status", "current employment status", "work status"],
  expectedSalary: ["expected salary", "expected package", "salary expectation", "expected ctq", "expected ctc", "desired salary", "expected remuneration"],
  currentSalary: ["current salary", "current package", "current ctc", "present salary", "present ctc"],
  handicapped: ["handicapped", "physically handicapped", "disability", "disabled", "special ability", "pwd", "person with disability"],
  healthIssues: ["health issues", "medical history", "health status", "medical conditions", "major illness"],
  targetRoles: ["target roles", "preferred roles", "desired roles"],
  coverLetterDraft: ["cover letter", "letter", "letter of intent", "cover_letter"],
  otherDocuments: ["other documents", "supporting documents", "additional documents", "certificates"],
  noticePeriod: ["notice period", "notice", "days to join", "joining time", "availability to join", "notice days"],
  totalExperience: ["total experience", "years of experience", "work experience", "experience in years", "experience (years)", "total work experience", "relevant experience"],
  
  // Behavioral & Application Q&A Vault
  q_why_hire: ["why should we hire you", "why hire", "why are you a good fit", "why fit for this role", "what makes you a good fit", "why you are the best candidate", "why should you be considered", "why do you think you are suitable"],
  q_why_company: ["why do you want to work here", "why our company", "why join us", "why this company", "what interests you about this role", "why do you want to join", "why work at", "motivation to join"],
  q_achievement: ["greatest achievement", "proudest project", "key accomplishment", "significant project", "major achievement", "most proud of", "key project"],
  q_challenge: ["challenge you overcame", "difficult technical challenge", "conflict you resolved", "handled a setback", "problem you solved", "overcame an obstacle", "complex situation"],
  q_strengths_weaknesses: ["strengths and weaknesses", "greatest strength", "area of improvement", "core strengths", "areas for improvement"],
  q_leadership: ["leadership experience", "demonstrated initiative", "led a project", "mentored someone", "leadership", "taking initiative"],
  
  edu10_school: ["10th school", "10th board school", "ssc school", "matriculation school", "school name (10", "class x school", "class 10 school", "secondary school name", "high school name"],
  edu10_board: ["10th board", "ssc board", "matriculation board", "class x board", "class 10 board", "secondary board", "secondary school board"],
  edu10_year: ["10th passing year", "10th year", "ssc passing year", "matric_year", "matric year", "matriculation passing year", "class x passing year", "class 10 passing year", "year of passing (10", "year of completion (10", "secondary passing year"],
  edu10_cgpa: ["10th cgpa", "10th percentage", "10th marks", "ssc cgpa", "ssc percentage", "ssc marks", "matriculation marks", "class x marks", "class x cgpa", "class 10 cgpa", "class 10 percentage"],
  
  edu12_school: ["12th school", "12th board school", "hsc school", "intermediate school", "school name (12", "class xii school", "class 12 school", "higher secondary school name", "senior secondary school name"],
  edu12_board: ["12th board", "hsc board", "intermediate board", "class xii board", "class 12 board", "higher secondary board", "senior secondary board"],
  edu12_year: ["12th passing year", "12th year", "hsc passing year", "intermediate passing year", "class xii passing year", "class 12 passing year", "year of passing (12", "year of completion (12", "higher secondary passing year"],
  edu12_cgpa: ["12th cgpa", "12th percentage", "12th marks", "hsc cgpa", "hsc percentage", "hsc marks", "intermediate marks", "intermediate cgpa", "class xii marks", "class xii cgpa", "class 12 cgpa", "class 12 percentage"],
  
  eduGrad_college: ["graduation college", "graduation university", "undergraduate college", "undergraduate university", "degree college", "bachelor college", "bachelor university", "college name", "university name"],
  eduGrad_degree: ["graduation degree", "undergraduate degree", "bachelor degree", "degree name", "bachelors degree"],
  eduGrad_stream: ["graduation stream", "graduation branch", "graduation discipline", "graduation major", "undergraduate major", "undergraduate stream", "undergraduate branch", "degree major", "degree stream", "degree branch", "branch/discipline", "specialization"],
  eduGrad_year: ["graduation passing year", "graduation year", "undergraduate passing year", "undergraduate year", "degree passing year", "degree year", "year of passing", "passing year", "completion year", "graduation date"],
  eduGrad_cgpa: ["graduation cgpa", "graduation percentage", "graduation marks", "undergraduate cgpa", "undergraduate percentage", "degree cgpa", "degree percentage", "gpa", "cgpa", "aggregate marks", "percentage of marks"],
  eduGrad_pursuing: ["graduation pursuing", "currently studying", "current student"],
  
  eduPG_college: ["pg college", "pg university", "post graduate college", "post graduate university", "post-graduate college", "postgraduate university"],
  eduPG_degree: ["pg degree", "post graduate degree", "post-graduate degree", "postgraduate degree"],
  eduPG_stream: ["pg stream", "pg branch", "pg discipline", "pg major", "post graduate major", "post graduate stream", "post graduate branch"],
  eduPG_year: ["pg passing year", "pg year", "post graduate passing year", "post graduate year"],
  eduPG_cgpa: ["pg cgpa", "pg percentage", "pg marks", "post graduate cgpa", "post graduate percentage"],
  eduPG_pursuing: ["pg pursuing"],
  
  eduMasters_college: ["masters college", "masters university", "master college", "master university"],
  eduMasters_degree: ["masters degree", "master degree", "master of"],
  eduMasters_stream: ["masters stream", "masters branch", "masters discipline", "masters major"],
  eduMasters_year: ["masters passing year", "masters year", "master passing year"],
  eduMasters_cgpa: ["masters cgpa", "masters percentage", "masters marks", "master cgpa"],
  eduMasters_pursuing: ["masters pursuing"],
  
  eduPhD_college: ["phd college", "phd university", "doctorate college", "doctorate university"],
  eduPhD_degree: ["phd degree", "doctorate degree"],
  eduPhD_stream: ["phd stream", "phd branch", "phd discipline", "phd major", "doctorate major"],
  eduPhD_year: ["phd passing year", "phd year", "doctorate passing year"],
  eduPhD_cgpa: ["phd cgpa", "phd percentage", "phd marks", "doctorate cgpa"],
  eduPhD_pursuing: ["phd pursuing"],

  // Master Screening & Compliance Vault Aliases
  workAuthStatus: ["work authorization", "authorized to work", "legally authorized to work", "work eligibility", "are you legally authorized", "right to work"],
  requireSponsorship: ["require sponsorship", "visa sponsorship", "future sponsorship", "require visa sponsorship", "sponsorship now or in the future", "will you require sponsorship", "immigration sponsorship"],
  visaType: ["visa type", "current visa", "citizenship status", "visa status", "immigration status", "work permit"],
  noticePeriodDays: ["notice period in days", "days of notice", "notice period", "joining time", "availability to join", "how many days notice"],
  willingToRelocate: ["willing to relocate", "relocation", "open to relocation", "relocate", "are you willing to relocate"],
  willingToTravel: ["willing to travel", "travel percentage", "travel willingness", "open to travel", "ability to travel"],
  earliestStartDate: ["earliest start date", "available start date", "start date", "availability date", "when can you start"],
  currentFixedSalary: ["current fixed salary", "current base salary", "current fixed", "current fixed ctc", "base salary"],
  currentSalaryCurrency: ["current salary currency", "currency"],
  expectedFixedSalary: ["expected fixed salary", "expected base salary", "expected fixed", "expected fixed ctc"],
  expectedSalaryCurrency: ["expected salary currency", "target currency"],
  salaryNegotiable: ["salary negotiable", "compensation flexible", "negotiable", "salary expectation flexible"],
  genderIdentity: ["gender identity", "gender", "self-identify gender", "what is your gender"],
  veteranStatus: ["veteran status", "veteran", "military status", "protected veteran status", "are you a veteran"],
  disabilityStatus: ["disability status", "disability", "voluntary self-identification of disability", "do you have a disability"],
  raceEthnicity: ["race", "ethnicity", "race/ethnicity", "hispanic or latino", "ethnic background"],
  legallyAuthorized: ["legally authorized", "authorized to work in", "eligible to work in"],
  previouslyEmployedHere: ["previously employed", "worked here before", "former employee", "ever worked for", "previous employment at"],
  hasRelativesHere: ["relatives employed", "relatives working", "family member at company", "any relatives working here"],
  securityClearance: ["security clearance", "clearance level", "active clearance", "government clearance"]
};

export const PORTAL_RULES = [
  {
    match: /naukri\.com/i,
    tier: "Tier 1 - Dedicated field-map",
    portal: "Naukri",
    notes: "Multi-step wizard, tag inputs, and bucketed salary fields."
  },
  {
    match: /linkedin\.com/i,
    tier: "Tier 1 - Dedicated field-map",
    portal: "LinkedIn",
    notes: "Easy Apply and profile forms need separate step handling."
  },
  {
    match: /wellfound\.com|angel\.co/i,
    tier: "Tier 1 - Dedicated field-map",
    portal: "Wellfound",
    notes: "Rich-text bio sections, selector overrides."
  },
  {
    match: /indeed\.com/i,
    tier: "Tier 1 - Dedicated field-map",
    portal: "Indeed",
    notes: "Form-level check overrides and redirection triggers."
  },
  {
    match: /myworkdayjobs\.com/i,
    tier: "Tier 2 - ATS-pattern map",
    portal: "Workday",
    notes: "Persistent wizard with strict validation and combobox widgets."
  },
  {
    match: /boards\.greenhouse\.io|job-boards\.greenhouse\.io/i,
    tier: "Tier 2 - ATS-pattern map",
    portal: "Greenhouse",
    notes: "Clean semantic HTML, strong core field mapping."
  },
  {
    match: /jobs\.lever\.co/i,
    tier: "Tier 2 - ATS-pattern map",
    portal: "Lever",
    notes: "Single-page form with some auto-parsed fields that must be verified."
  },
  {
    match: /icims\.com/i,
    tier: "Tier 2 - ATS-pattern map",
    portal: "iCIMS",
    notes: "Strict formatting and rigid multi-page validation."
  },
  {
    match: /smartrecruiters\.com/i,
    tier: "Tier 2 - ATS-pattern map",
    portal: "SmartRecruiters",
    notes: "Modern single-page form with conversational screening questions."
  }
];

export function getPortalRule(url) {
  const target = String(url || "");
  return PORTAL_RULES.find((rule) => rule.match.test(target)) || {
    tier: "Tier 3 - Default heuristic engine",
    portal: "Unknown",
    notes: "Fallback confidence-scoring engine with manual review flags."
  };
}

export const PORTAL_MAPS = {
  LinkedIn: {
    fullName: "input[aria-label*='Full name'], input[placeholder*='Full name'], input[name*='fullName']",
    firstName: "input[aria-label*='First name'], input[placeholder*='First name'], input[name*='firstName']",
    lastName: "input[aria-label*='Last name'], input[placeholder*='Last name'], input[name*='lastName']",
    email: "input[aria-label*='Email'], input[placeholder*='Email'], input[type='email']",
    phone: "input[aria-label*='Phone'], input[placeholder*='Phone'], input[name*='phone']",
    linkedin: "input[aria-label*='LinkedIn'], input[placeholder*='LinkedIn']",
    resume: "input[type='file'], input[accept*='pdf'], input[accept*='doc']"
  },
  Naukri: {
    fullName: "input[placeholder*='Name'], input[name*='name'], input[aria-label*='Name']",
    email: "input[placeholder*='Email'], input[name*='email'], input[type='email']",
    phone: "input[placeholder*='Mobile'], input[name*='mobile'], input[name*='phone']",
    resume: "input[type='file'][name*='resume'], input[type='file']",
    college: "input[placeholder*='College'], input[name*='college']"
  },
  Wellfound: {
    fullName: "input[name*='name'], input[placeholder*='name'], input[aria-label*='name']",
    email: "input[name*='email'], input[type='email']",
    phone: "input[name*='phone'], input[name*='mobile']",
    resume: "input[type='file']",
    linkedin: "input[name*='linkedin'], input[placeholder*='linkedin']",
    portfolio: "input[name*='portfolio'], input[placeholder*='portfolio']"
  },
  Indeed: {
    fullName: "input[id*='name'], input[name*='name'], input[placeholder*='name']",
    email: "input[type='email'], input[id*='email'], input[name*='email']",
    phone: "input[type='tel'], input[id*='phone'], input[name*='phone']",
    resume: "input[type='file']",
    city: "input[id*='city'], input[name*='city']",
    country: "input[id*='country'], input[name*='country']"
  },
  Greenhouse: {
    fullName: "#first_name, #last_name, #name, input[name*='name'], input[name*='first_name']",
    email: "#email, input[name*='email']",
    phone: "#phone, input[name*='phone']",
    resume: "#resume_file, input[type='file']",
    linkedin: "input[placeholder*='LinkedIn'], input[name*='linkedin']"
  },
  Lever: {
    fullName: "input[name*='name']",
    email: "input[name*='email']",
    phone: "input[name*='phone']",
    resume: "input[type='file']",
    linkedin: "input[name*='linkedin'], input[placeholder*='linkedin']"
  }
};

export function getPhoneCode(profile) {
  const phone = String(profile.phone || "");
  if (phone.startsWith("+")) {
    const match = phone.match(/^\+(\d+)/);
    if (match) return match[1]; // e.g. "91"
  }
  const country = String(profile.country || "").toLowerCase();
  const address = String(profile.address || "").toLowerCase();
  if (country.includes("india") || address.includes("india")) return "91";
  if (country.includes("united states") || country.includes("usa") || country.includes("us")) return "1";
  if (country.includes("united kingdom") || country.includes("uk")) return "44";
  return "";
}

export function buildAutofillPayload(profile, requestedFields) {
  const fields = requestedFields.length ? requestedFields : DEFAULT_PROFILE_FIELDS;
  const payload = {};
  const profileLower = {};
  for (const [k, v] of Object.entries(profile || {})) {
    profileLower[k.toLowerCase()] = v;
  }
  for (const field of fields) {
    const key = field.toLowerCase();
    if (key === "resume") {
      payload[field] = profileLower["resumedraft"] || profileLower["resume"] || "";
    } else if (key === "phonecode") {
      payload[field] = getPhoneCode(profile);
    } else if (profileLower[key] !== undefined) {
      payload[field] = profileLower[key];
    } else {
      payload[field] = "";
    }
  }
  return {
    createdAt: new Date().toISOString(),
    source: "jobxapply-profile",
    fields,
    payload
  };
}

export function summarizeProfile(profile = {}) {
  const lines = [];
  for (const key of DEFAULT_PROFILE_FIELDS) {
    lines.push(`${key}: ${profile[key] || ""}`);
  }
  return lines.join("\n");
}

export function uint8ToBase64(uint8) {
  let bin = "";
  const len = uint8.byteLength;
  for (let i = 0; i < len; i++) {
    bin += String.fromCharCode(uint8[i]);
  }
  return btoa(bin);
}

export function base64ToUint8(base64) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function generatePasscodeHash(passcode) {
  if (!passcode) return "";
  const encoder = new TextEncoder();
  const data = encoder.encode(passcode + ":jobxapply_salt_v2");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return uint8ToBase64(new Uint8Array(hashBuffer));
}

async function deriveKey(passcode, saltBytes) {
  const encoder = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    "raw",
    encoder.encode(passcode),
    "PBKDF2",
    false,
    ["deriveKey"]
  );
  
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: saltBytes,
      iterations: 100000,
      hash: "SHA-256"
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function encryptProfileData(profile, passcode) {
  if (!profile) return null;
  if (!passcode) {
    throw new Error("Encryption key/passcode required");
  }

  const publicMetadata = {
    fullName: profile.fullName || "",
    headline: profile.headline || "",
    targetRole: profile.targetRole || ""
  };

  const privateDetails = {};
  for (const field of DEFAULT_PROFILE_FIELDS) {
    if (field !== "fullName" && field !== "headline" && field !== "targetRole") {
      privateDetails[field] = profile[field] || "";
    }
  }

  const plaintext = JSON.stringify(privateDetails);
  const encoder = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await deriveKey(passcode, salt);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  
  const ciphertextBuffer = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    encoder.encode(plaintext)
  );

  return {
    ...publicMetadata,
    encryptedBlob: {
      ciphertext: uint8ToBase64(new Uint8Array(ciphertextBuffer)),
      iv: uint8ToBase64(iv),
      salt: uint8ToBase64(salt)
    }
  };
}

export async function decryptProfileData(encryptedProfile, passcode) {
  if (!encryptedProfile) return {};
  if (!encryptedProfile.encryptedBlob) {
    return encryptedProfile;
  }
  if (!passcode) {
    throw new Error("Decryption passcode required");
  }

  const blob = encryptedProfile.encryptedBlob;
  const salt = base64ToUint8(blob.salt);
  const iv = base64ToUint8(blob.iv);
  const ciphertext = base64ToUint8(blob.ciphertext);
  
  const key = await deriveKey(passcode, salt);
  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    key,
    ciphertext
  );

  const decoder = new TextDecoder();
  const privateJson = decoder.decode(decryptedBuffer);
  const privateDetails = JSON.parse(privateJson);

  const fullProfile = {};
  for (const field of DEFAULT_PROFILE_FIELDS) {
    if (field === "fullName" || field === "headline" || field === "targetRole") {
      fullProfile[field] = encryptedProfile[field] || "";
    } else {
      fullProfile[field] = privateDetails[field] || "";
    }
  }

  return fullProfile;
}

export function cloneProfile(profile = {}, newName) {
  const cloned = { ...profile };
  cloned.id = newName.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  if (!cloned.id) {
    cloned.id = "profile-" + Date.now().toString(36);
  }
  cloned.profileName = newName;
  return cloned;
}

